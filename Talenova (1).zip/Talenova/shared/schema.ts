import { z } from "zod";
import { sql } from "drizzle-orm";
import { pgTable, text, integer, varchar, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// Session storage table for Replit Auth
// Reference: javascript_log_in_with_replit integration
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - supports both email/password and OAuth authentication
// Password is optional (null for OAuth users)
// oauthSub stores OAuth provider's user ID for reconciliation
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  password: varchar("password"),
  oauthSub: varchar("oauth_sub").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type UpsertUser = typeof users.$inferInsert;

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const registerUserSchema = insertUserSchema.pick({
  email: true,
  password: true,
  firstName: true,
  lastName: true,
}).extend({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const loginUserSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(1, "Password is required"),
});

// Password reset tokens for forgot password functionality
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  token: varchar("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = typeof passwordResetTokens.$inferInsert;

export const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Reset token is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const updateUserSchema = z.object({
  firstName: z.string().min(1, "First name cannot be empty").optional(),
  lastName: z.string().min(1, "Last name cannot be empty").optional(),
  profileImageUrl: z.string().url("Profile image must be a valid URL").or(z.literal("")).optional(),
});

export const stories = pgTable("stories", {
  id: varchar("id").primaryKey(),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  region: varchar("region").notNull(),
  country: varchar("country").notNull(),
  language: varchar("language").notNull(),
  category: varchar("category").notNull(),
  ageGroup: varchar("age_group").notNull(),
  moral: text("moral").notNull(),
  culturalContext: text("cultural_context").notNull(),
  difficulty: integer("difficulty").notNull(),
  character: varchar("character").notNull(),
});

export type Story = typeof stories.$inferSelect;
export type InsertStory = typeof stories.$inferInsert;
export const insertStorySchema = createInsertSchema(stories);

export const userProgress = pgTable("user_progress", {
  userId: varchar("user_id").primaryKey(),
  completedStories: text("completed_stories").array().notNull().default([]),
  points: integer("points").notNull().default(0),
  badges: text("badges").array().notNull().default([]),
  currentStreak: integer("current_streak").notNull().default(0),
});

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = typeof userProgress.$inferInsert;
export const insertUserProgressSchema = createInsertSchema(userProgress);

export const languagePhrases = pgTable("language_phrases", {
  id: varchar("id").primaryKey(),
  language: varchar("language").notNull(),
  phrase: varchar("phrase").notNull(),
  translation: varchar("translation").notNull(),
  pronunciation: varchar("pronunciation").notNull(),
  category: varchar("category").notNull(),
});

export type LanguagePhrase = typeof languagePhrases.$inferSelect;
export type InsertLanguagePhrase = typeof languagePhrases.$inferInsert;
export const insertLanguagePhraseSchema = createInsertSchema(languagePhrases);

export const proverbs = pgTable("proverbs", {
  id: varchar("id").primaryKey(),
  proverb: text("proverb").notNull(),
  meaning: text("meaning").notNull(),
  culture: varchar("culture").notNull(),
  category: varchar("category").notNull(),
});

export type Proverb = typeof proverbs.$inferSelect;
export type InsertProverb = typeof proverbs.$inferInsert;
export const insertProverbSchema = createInsertSchema(proverbs);

export const badges = pgTable("badges", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description").notNull(),
  icon: varchar("icon").notNull(),
  requirement: varchar("requirement").notNull(),
});

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = typeof badges.$inferInsert;
export const insertBadgeSchema = createInsertSchema(badges);

export const gameScores = pgTable("game_scores", {
  id: varchar("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  gameType: varchar("game_type").notNull(),
  score: integer("score").notNull(),
  completedAt: timestamp("completed_at").notNull(),
});

export type GameScore = typeof gameScores.$inferSelect;
export type InsertGameScore = typeof gameScores.$inferInsert;
export const insertGameScoreSchema = createInsertSchema(gameScores);

export type AIStoryRequest = {
  character: string;
  moral: string;
  theme: string;
  ageGroup: '4-7' | '8-10' | '11-13';
  supportingCharacter?: string;
  storyTone?: string;
  specialElement?: string;
  timeOfDay?: string;
  conflict?: string;
};

export const aiStoryRequestSchema = z.object({
  character: z.string().min(1, "Please select a character"),
  moral: z.string().min(1, "Please select a moral lesson"),
  theme: z.string().min(1, "Please select a theme"),
  ageGroup: z.enum(['4-7', '8-10', '11-13']),
  supportingCharacter: z.string().optional(),
  storyTone: z.string().optional(),
  specialElement: z.string().optional(),
  timeOfDay: z.string().optional(),
  conflict: z.string().optional(),
});

export type AIStoryResponse = {
  title: string;
  content: string;
  moral: string;
  culturalContext: string;
};
