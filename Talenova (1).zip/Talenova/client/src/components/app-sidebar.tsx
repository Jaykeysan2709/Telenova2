import { BookOpen, Gamepad2, Map, GraduationCap, User, Sparkles, Trophy, Settings, Lightbulb, Info } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import talenovaLogo from "@assets/generated_images/Talenova_educational_logo_design_11327ce9.png";

const menuItems = [
  {
    title: "Discover",
    url: "/",
    icon: Sparkles,
  },
  {
    title: "Stories",
    url: "/stories",
    icon: BookOpen,
  },
  {
    title: "Story Builder",
    url: "/story-builder",
    icon: Sparkles,
  },
  {
    title: "Proverbs",
    url: "/proverbs",
    icon: Lightbulb,
  },
  {
    title: "Cultural Map",
    url: "/map",
    icon: Map,
  },
  {
    title: "Learn",
    url: "/learn",
    icon: GraduationCap,
  },
  {
    title: "Games",
    url: "/games",
    icon: Gamepad2,
  },
  {
    title: "My Progress",
    url: "/progress",
    icon: Trophy,
  },
  {
    title: "Profile",
    url: "/profile",
    icon: Settings,
  },
  {
    title: "About Us",
    url: "/about",
    icon: Info,
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="p-6 pb-4">
        <div className="flex items-center gap-3">
          <img 
            src={talenovaLogo} 
            alt="Tale-Nova" 
            className="h-10 w-10 rounded-lg object-cover" 
            data-testid="logo-talenova"
          />
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground" data-testid="text-app-title">Tale-Nova</h1>
            <p className="text-xs text-muted-foreground" data-testid="text-app-subtitle">old stories, new way</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-3">
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                  >
                    <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(' ', '-')}`}>
                      <item.icon className="h-5 w-5" />
                      <span className="font-medium">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
