import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import { type Story } from "@shared/schema";

interface StoryCardProps {
  story: Story;
  onClick?: () => void;
}

export function StoryCard({ story, onClick }: StoryCardProps) {
  const difficultyStars = Array.from({ length: 3 }, (_, i) => i < story.difficulty);

  return (
    <Card
      className="p-6 cursor-pointer transition-all hover-elevate active-elevate-2 border-card-border"
      onClick={onClick}
      data-testid={`card-story-${story.id}`}
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-heading text-xl font-bold text-foreground leading-tight" data-testid={`text-story-title-${story.id}`}>
              {story.title}
            </h3>
            <div className="flex gap-1" data-testid={`difficulty-stars-${story.id}`}>
              {difficultyStars.map((filled, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    filled ? "fill-primary text-primary" : "text-muted"
                  }`}
                />
              ))}
            </div>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-story-preview-${story.id}`}>
            {story.content.substring(0, 120)}...
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" className="text-xs" data-testid={`badge-region-${story.id}`}>
            {story.region}
          </Badge>
          <Badge variant="outline" className="text-xs" data-testid={`badge-age-${story.id}`}>
            Ages {story.ageGroup}
          </Badge>
          <Badge className="bg-accent text-accent-foreground text-xs" data-testid={`badge-category-${story.id}`}>
            {story.category}
          </Badge>
        </div>

        <div className="pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground" data-testid={`text-character-${story.id}`}>
            <span className="font-semibold">Main Character:</span> {story.character}
          </p>
        </div>
      </div>
    </Card>
  );
}
