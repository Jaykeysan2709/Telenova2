import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, BookOpen, Trophy, Globe } from "lucide-react";
import { Link } from "wouter";
import { type Story, type Proverb } from "@shared/schema";
import { StoryCard } from "@/components/story-card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: featuredStories, isLoading: storiesLoading } = useQuery<Story[]>({
    queryKey: ["/api/stories/featured"],
  });

  const { data: dailyProverb, isLoading: proverbLoading } = useQuery<Proverb>({
    queryKey: ["/api/proverbs/daily"],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/20 via-accent/10 to-background">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,150,50,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(100,200,100,0.1),transparent_50%)]" />
        
        <div className="relative max-w-6xl mx-auto px-6 py-16 md:py-24">
          <div className="text-center space-y-6">
            <Badge className="text-sm px-4 py-1.5">
              Welcome to Tale-Nova
            </Badge>
            <h1 className="font-heading text-5xl md:text-6xl lg:text-7xl font-bold text-foreground tracking-tight">
              Discover the Magic of{" "}
              <span className="text-primary">African Stories</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Connect with deep African folklore, languages, and cultural wisdom through
              fun, immersive storytelling created just for you.
            </p>
            <div className="flex flex-wrap gap-4 justify-center pt-6">
              <Button
                size="lg"
                className="h-12 px-8 text-base font-semibold"
                asChild
              >
                <Link href="/stories" data-testid="button-explore-stories">
                  <BookOpen className="mr-2 h-5 w-5" />
                  Explore Stories
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 px-8 text-base font-semibold backdrop-blur-sm"
                asChild
              >
                <Link href="/story-builder" data-testid="button-create-story">
                  <Sparkles className="mr-2 h-5 w-5" />
                  Create Your Story
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-12">
        <section>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-heading text-3xl font-bold text-foreground">
                Featured Stories
              </h2>
              <p className="text-muted-foreground mt-1">
                Hand-picked tales from across Africa
              </p>
            </div>
            <Button variant="ghost" asChild>
              <Link href="/stories" data-testid="button-view-all-stories">View All</Link>
            </Button>
          </div>

          {storiesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="p-6 space-y-4">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                </Card>
              ))}
            </div>
          ) : featuredStories && featuredStories.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredStories.slice(0, 3).map((story) => (
                <Link key={story.id} href={`/stories/${story.id}`} data-testid={`link-story-${story.id}`}>
                  <StoryCard story={story} />
                </Link>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No featured stories yet</p>
            </Card>
          )}
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 hover-elevate cursor-pointer">
            <Link href="/map" data-testid="link-cultural-map">
              <div className="space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Globe className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-heading text-xl font-bold">Cultural Map</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    Explore stories from different regions of Africa
                  </p>
                </div>
              </div>
            </Link>
          </Card>

          <Card className="p-6 hover-elevate cursor-pointer">
            <Link href="/learn" data-testid="link-learn">
              <div className="space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/50 text-accent-foreground">
                  <BookOpen className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-heading text-xl font-bold">Learn Languages</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    Master Yoruba, Swahili, Igbo, Zulu, and Hausa phrases
                  </p>
                </div>
              </div>
            </Link>
          </Card>

          <Card className="p-6 hover-elevate cursor-pointer">
            <Link href="/games" data-testid="link-games">
              <div className="space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-chart-2/20 text-chart-2">
                  <Trophy className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-heading text-xl font-bold">Play Games</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    Test your knowledge with fun quizzes and challenges
                  </p>
                </div>
              </div>
            </Link>
          </Card>
        </section>

        {dailyProverb && !proverbLoading && (
          <section>
            <Card className="p-8 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <div className="space-y-4">
                <Badge className="text-xs" data-testid="badge-proverb-of-day">Proverb of the Day</Badge>
                <blockquote className="font-heading text-2xl md:text-3xl font-bold text-foreground italic" data-testid="text-daily-proverb">
                  "{dailyProverb.proverb}"
                </blockquote>
                <p className="text-muted-foreground leading-relaxed" data-testid="text-proverb-meaning">
                  {dailyProverb.meaning}
                </p>
                <p className="text-sm text-muted-foreground" data-testid="text-proverb-culture">
                  — {dailyProverb.culture} wisdom
                </p>
              </div>
            </Card>
          </section>
        )}
      </div>
    </div>
  );
}
