import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Gamepad2, Trophy, Star, CheckCircle2, XCircle, Theater, Sparkles, ArrowRight, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type GameType = "guess-animal" | "match-proverb" | "story-origin" | "live-story";

const guessAnimalQuestions = [
  {
    question: "In West African folklore, which clever creature is known for outsmarting larger animals?",
    options: ["Spider", "Tortoise", "Hare", "Snake"],
    correct: "Spider",
    hint: "Anansi",
  },
  {
    question: "What animal is often portrayed as wise and patient in African tales?",
    options: ["Lion", "Elephant", "Cheetah", "Crocodile"],
    correct: "Elephant",
    hint: "Known for memory and wisdom",
  },
  {
    question: "In many African stories, this slow creature is surprisingly cunning:",
    options: ["Snail", "Tortoise", "Chameleon", "Beetle"],
    correct: "Tortoise",
    hint: "Slow but clever",
  },
];

const matchProverbQuestions = [
  {
    proverb: "When the mouse laughs at the cat, there is a hole nearby",
    meaning: "Be confident only when you have a way out",
    culture: "Nigerian",
  },
  {
    proverb: "A tree cannot stand without roots",
    meaning: "Know and respect your origins",
    culture: "African",
  },
  {
    proverb: "The child who is not embraced by the village will burn it down to feel its warmth",
    meaning: "Community support is essential",
    culture: "African",
  },
];

interface StoryScene {
  id: string;
  title: string;
  narrative: string;
  characterThought?: string;
  choices?: {
    text: string;
    nextScene: string;
    consequence: string;
    points: number;
  }[];
  isEnding?: boolean;
  endingType?: "good" | "great" | "best";
  moral?: string;
}

interface InteractiveStory {
  id: string;
  title: string;
  description: string;
  region: string;
  ageGroup: string;
  characterName: string;
  characterRole: string;
  scenes: StoryScene[];
}

const liveStories: InteractiveStory[] = [
  {
    id: "anansi-wisdom",
    title: "Anansi and the Pot of Wisdom",
    description: "Step into the role of Anansi the Spider and decide how to share wisdom with the world.",
    region: "West Africa (Ghana)",
    ageGroup: "6-10",
    characterName: "Anansi",
    characterRole: "the clever spider",
    scenes: [
      {
        id: "start",
        title: "The Beginning",
        narrative: "You are Anansi, the clever spider of West Africa! The Sky God Nyame has given you a magical pot containing ALL the wisdom in the world. You hold it tightly, feeling its power. 'With this wisdom, I could become the most powerful being!' you think. But you notice other animals watching you curiously.",
        characterThought: "This wisdom is incredible! But what should I do with it?",
        choices: [
          {
            text: "Hide the pot so no one else can have the wisdom",
            nextScene: "hide-wisdom",
            consequence: "You decide to keep all the wisdom for yourself",
            points: 5
          },
          {
            text: "Share some wisdom with the curious animals",
            nextScene: "share-wisdom",
            consequence: "You decide to be generous and share",
            points: 15
          },
          {
            text: "Ask the animals what they would do with wisdom",
            nextScene: "ask-animals",
            consequence: "You want to learn from others first",
            points: 10
          }
        ]
      },
      {
        id: "hide-wisdom",
        title: "The Climb",
        narrative: "You decide to hide the pot at the top of the tallest tree in the forest. You tie the pot to your belly and begin climbing. But the pot is heavy and keeps bumping against the trunk, making it very difficult to climb! Your son, Ntikuma, watches from below.",
        characterThought: "This is harder than I thought! The pot keeps getting in my way!",
        choices: [
          {
            text: "Keep struggling up the tree alone",
            nextScene: "struggle-alone",
            consequence: "You refuse to accept any help",
            points: 5
          },
          {
            text: "Listen when Ntikuma suggests tying the pot to your back",
            nextScene: "listen-son",
            consequence: "You accept wisdom from your young son",
            points: 15
          }
        ]
      },
      {
        id: "share-wisdom",
        title: "The Gathering",
        narrative: "You call all the animals together. The elephant, the lion, the tortoise, and many others gather around. You open the pot and share pieces of wisdom with each animal. The elephant learns patience, the lion learns fairness, and the tortoise learns perseverance. The animals are grateful and share their own knowledge with you!",
        characterThought: "By giving wisdom away, I'm actually learning MORE! Everyone has something to teach!",
        choices: [
          {
            text: "Continue sharing until the pot is empty",
            nextScene: "empty-pot-good",
            consequence: "You give away all the wisdom freely",
            points: 20
          },
          {
            text: "Keep a little wisdom just for yourself",
            nextScene: "keep-some",
            consequence: "You share most but save some",
            points: 10
          }
        ]
      },
      {
        id: "ask-animals",
        title: "Learning from Others",
        narrative: "You ask the animals what they would do with wisdom. The tortoise says, 'I would share it, for wisdom grows when shared.' The elephant says, 'I would use it to help others.' The bird says, 'I would spread it across the land like seeds.' You realize that these animals already have wisdom of their own!",
        characterThought: "I thought I had ALL the wisdom, but everyone has something wise to share!",
        choices: [
          {
            text: "Combine your wisdom with theirs",
            nextScene: "combine-wisdom",
            consequence: "You create something even greater together",
            points: 20
          },
          {
            text: "Thank them and go off to think alone",
            nextScene: "think-alone",
            consequence: "You need time to process what you learned",
            points: 10
          }
        ]
      },
      {
        id: "struggle-alone",
        title: "The Fall",
        narrative: "You keep climbing, but the pot is just too awkward. Suddenly, you slip! The pot falls from your grasp and CRASHES on the ground below. Wisdom scatters everywhere on the wind, spreading across the whole world! Now everyone has a little bit of wisdom.",
        characterThought: "Oh no! But wait... maybe this is better? Now wisdom belongs to everyone!",
        isEnding: true,
        endingType: "good",
        moral: "Sometimes our mistakes lead to the best outcomes. Wisdom is meant to be shared, not hoarded."
      },
      {
        id: "listen-son",
        title: "A Lesson in Humility",
        narrative: "Ntikuma calls out: 'Father! If you tie the pot to your BACK instead of your front, you could climb easily!' You realize your son is right! You feel embarrassed that you, with all the wisdom in the world, didn't think of something so simple. You laugh and climb down.",
        characterThought: "My own child taught me something! No one can have ALL the wisdom!",
        choices: [
          {
            text: "Thank Ntikuma and share the wisdom with everyone",
            nextScene: "best-ending",
            consequence: "You learn the true meaning of wisdom",
            points: 25
          },
          {
            text: "Feel embarrassed and keep the pot hidden",
            nextScene: "embarrassed-hide",
            consequence: "Pride makes you hide your lesson",
            points: 5
          }
        ]
      },
      {
        id: "empty-pot-good",
        title: "The Generous Spider",
        narrative: "You share every last drop of wisdom from the pot. The animals celebrate you as the most generous spider! And something magical happens - as you gave wisdom away, new wisdom filled your heart. You realize that wisdom MULTIPLIES when shared!",
        isEnding: true,
        endingType: "great",
        moral: "True wisdom grows when shared with others. The more you give, the more you receive."
      },
      {
        id: "keep-some",
        title: "The Reserved Spider",
        narrative: "You share most of the wisdom but keep a small portion for yourself. The animals are grateful, but you notice the wisdom you kept doesn't seem as bright or powerful as what you shared. Wisdom, it seems, shines brightest when it illuminates others.",
        isEnding: true,
        endingType: "good",
        moral: "Sharing brings more joy than keeping. Wisdom held too tightly loses its light."
      },
      {
        id: "combine-wisdom",
        title: "The Council of Wisdom",
        narrative: "You pour the pot's wisdom into the circle of animals, and they add their own wisdom too! Together, you create the first Council of Wisdom. From that day on, whenever anyone has a problem, they come to the council where EVERYONE'S wisdom helps find the answer!",
        isEnding: true,
        endingType: "best",
        moral: "The greatest wisdom comes from many minds working together. Community is our greatest treasure."
      },
      {
        id: "think-alone",
        title: "The Thoughtful Spider",
        narrative: "You go off to a quiet place to think. After much reflection, you realize that wisdom isn't something to own - it's something to practice. You return to share the pot with everyone, knowing that each creature will use wisdom in their own special way.",
        isEnding: true,
        endingType: "good",
        moral: "Taking time to reflect helps us make better choices. Wisdom requires patience."
      },
      {
        id: "best-ending",
        title: "The Wisest Choice",
        narrative: "You hug Ntikuma and thank him for the lesson. Then you call all the animals together and tell them: 'I thought I had all the wisdom, but my own son taught me something I didn't know! Let's share this pot together, for wisdom belongs to everyone!' The animals cheer, and from that day on, wisdom spread across all of Africa.",
        isEnding: true,
        endingType: "best",
        moral: "True wisdom is knowing that you can always learn from others, even the youngest among us. Pride blocks wisdom, but humility opens the door."
      },
      {
        id: "embarrassed-hide",
        title: "The Hidden Pot",
        narrative: "Feeling embarrassed, you hide the pot in a cave. But keeping it hidden makes you feel lonely and sad. Wisdom isn't meant to be locked away in darkness. Eventually, you realize that being wrong isn't shameful - it's how we learn.",
        isEnding: true,
        endingType: "good",
        moral: "It's okay to make mistakes. What matters is what we do next. Don't let embarrassment stop you from doing what's right."
      }
    ]
  },
  {
    id: "tortoise-feast",
    title: "Tortoise and the Birds' Feast",
    description: "Become the clever Tortoise and navigate a feast in the sky. Will you choose kindness or trickery?",
    region: "West Africa (Nigeria)",
    ageGroup: "7-12",
    characterName: "Mbe",
    characterRole: "the clever tortoise",
    scenes: [
      {
        id: "start",
        title: "The Invitation",
        narrative: "You are Mbe the Tortoise! You've heard that the birds are flying to a great feast in the sky, hosted by the Sky People. The food there is supposed to be the most delicious in all the world! But you have no wings. The birds are gathering to leave.",
        characterThought: "That feast sounds amazing! But how can I, a tortoise, reach the sky?",
        choices: [
          {
            text: "Ask the birds politely if they can help you attend",
            nextScene: "ask-politely",
            consequence: "You approach with humility and respect",
            points: 15
          },
          {
            text: "Try to trick the birds into taking you",
            nextScene: "trick-birds",
            consequence: "You plan a clever scheme",
            points: 5
          },
          {
            text: "Wish the birds well and stay home",
            nextScene: "stay-home",
            consequence: "You accept your limitations gracefully",
            points: 10
          }
        ]
      },
      {
        id: "ask-politely",
        title: "A Kind Request",
        narrative: "You approach the birds with respect. 'Dear friends,' you say, 'I've heard of the wonderful feast in the sky. I know I have no wings, but I would love to experience it with you. Is there any way you could help me?' The birds look at each other and smile at your humble request.",
        characterThought: "Being honest feels right. I hope they understand.",
        choices: [
          {
            text: "Offer to tell stories to entertain them on the journey",
            nextScene: "offer-stories",
            consequence: "You offer something in return",
            points: 15
          },
          {
            text: "Promise to bring back gifts for birds who can't attend",
            nextScene: "promise-gifts",
            consequence: "You think of others too",
            points: 20
          }
        ]
      },
      {
        id: "trick-birds",
        title: "The Scheme",
        narrative: "You tell the birds a lie: 'In the sky kingdom, guests must have special names! I'll help you all choose sky-names.' The birds are excited and each takes a new name. Then you cleverly name yourself 'All of You' in the sky language. When you arrive and food is served 'for all of you,' you plan to eat it all!",
        characterThought: "This is so clever! But... is it right to trick my friends?",
        choices: [
          {
            text: "Go through with the trick",
            nextScene: "complete-trick",
            consequence: "You deceive your friends",
            points: 0
          },
          {
            text: "Confess your trick and apologize",
            nextScene: "confess-trick",
            consequence: "You choose honesty over cleverness",
            points: 20
          }
        ]
      },
      {
        id: "stay-home",
        title: "Contentment",
        narrative: "You wave goodbye to the birds and return home. That evening, you gather your family and tell them stories of imaginary feasts in the sky. Your children laugh and clap. The parrot returns later and shares some sky-fruit with you as thanks for not begging to come along.",
        isEnding: true,
        endingType: "good",
        moral: "Sometimes the greatest joy comes from accepting what we have and finding happiness at home."
      },
      {
        id: "offer-stories",
        title: "The Storyteller's Journey",
        narrative: "The birds love your idea! Each bird gives you one feather, and together they create wings for you. As you all fly to the feast, you tell wonderful stories that make the journey fly by. The Sky People are so impressed by your stories that they give you the seat of honor!",
        characterThought: "Sharing my gift of storytelling has opened doors I never imagined!",
        choices: [
          {
            text: "Share the best food with all the birds",
            nextScene: "share-feast",
            consequence: "You honor those who helped you",
            points: 20
          },
          {
            text: "Accept the honor humbly",
            nextScene: "humble-honor",
            consequence: "You remain grateful and humble",
            points: 15
          }
        ]
      },
      {
        id: "promise-gifts",
        title: "A Generous Heart",
        narrative: "The birds are touched by your thoughtfulness. 'You think of others even when asking for yourself,' says the wise owl. 'That is true kindness.' They happily share their feathers to make you wings. At the feast, the Sky People hear of your promise and give you extra gifts to share!",
        isEnding: true,
        endingType: "best",
        moral: "When we think of others, blessings multiply. Generosity opens the doors that selfishness closes."
      },
      {
        id: "complete-trick",
        title: "The Bitter Feast",
        narrative: "Your trick works, and you eat most of the food while the birds watch in shock. But the birds are angry! On the way home, they each take back their feathers. You fall from the sky! You survive, but your shell is cracked forever, and the birds never trust you again.",
        isEnding: true,
        endingType: "good",
        moral: "Tricks may bring short-term gain, but they destroy trust and friendship. What we gain by deception, we lose in respect."
      },
      {
        id: "confess-trick",
        title: "The Brave Confession",
        narrative: "Before the feast begins, you stand up and confess your trick to everyone. 'I was wrong to try to deceive you,' you say. The birds are upset at first, but then the wise eagle speaks: 'It takes more courage to admit wrong than to commit it. We forgive you.' The feast is shared fairly, and you gain true friends.",
        isEnding: true,
        endingType: "best",
        moral: "Admitting our mistakes takes great courage. Honesty may be hard, but it builds lasting trust and friendship."
      },
      {
        id: "share-feast",
        title: "The Honored Guest",
        narrative: "You insist that your bird friends sit beside you at the place of honor. You make sure everyone gets the best food before you take any. The Sky People are so impressed that they name you 'Friend of the Sky' and invite you back anytime - the birds will always be happy to carry you!",
        isEnding: true,
        endingType: "best",
        moral: "True honor comes from honoring others. When we lift others up, we rise together."
      },
      {
        id: "humble-honor",
        title: "The Grateful Tortoise",
        narrative: "You accept the honor with thanks, always remembering to praise the birds who made your journey possible. The feast is wonderful, and you return home with beautiful memories and new friends. The birds speak kindly of you, and other animals admire your humble spirit.",
        isEnding: true,
        endingType: "great",
        moral: "Humility is the companion of true achievement. Never forget those who helped you along the way."
      }
    ]
  }
];

export default function Games() {
  const [selectedGame, setSelectedGame] = useState<GameType | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const { toast } = useToast();

  // Live Story state
  const [selectedStory, setSelectedStory] = useState<InteractiveStory | null>(null);
  const [currentSceneId, setCurrentSceneId] = useState<string>("start");
  const [storyScore, setStoryScore] = useState(0);
  const [storyPath, setStoryPath] = useState<string[]>([]);
  const [storyComplete, setStoryComplete] = useState(false);

  const saveScore = useMutation({
    mutationFn: async ({ gameType, score }: { gameType: string; score: number }) => {
      const response = await apiRequest("POST", "/api/game-scores", { gameType, score });
      return response.json();
    },
  });

  const handleGameSelect = (game: GameType) => {
    setSelectedGame(game);
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
    setSelectedStory(null);
    setCurrentSceneId("start");
    setStoryScore(0);
    setStoryPath([]);
    setStoryComplete(false);
  };

  const handleStorySelect = (story: InteractiveStory) => {
    setSelectedStory(story);
    setCurrentSceneId("start");
    setStoryScore(0);
    setStoryPath(["start"]);
    setStoryComplete(false);
  };

  const handleStoryChoice = (choice: { nextScene: string; points: number; consequence: string }) => {
    setStoryScore(storyScore + choice.points);
    setStoryPath([...storyPath, choice.nextScene]);
    setCurrentSceneId(choice.nextScene);

    const nextScene = selectedStory?.scenes.find(s => s.id === choice.nextScene);
    if (nextScene?.isEnding) {
      setStoryComplete(true);
      saveScore.mutate({ gameType: "live-story", score: storyScore + choice.points });
      toast({
        title: "Story Complete!",
        description: `You earned ${storyScore + choice.points} wisdom points!`,
      });
    }
  };

  const getCurrentScene = (): StoryScene | undefined => {
    return selectedStory?.scenes.find(s => s.id === currentSceneId);
  };

  const restartStory = () => {
    setCurrentSceneId("start");
    setStoryScore(0);
    setStoryPath(["start"]);
    setStoryComplete(false);
  };

  const handleAnswer = (answer: string) => {
    const question = guessAnimalQuestions[currentQuestion];
    const isCorrect = answer === question.correct;
    
    setSelectedAnswer(answer);
    
    if (isCorrect) {
      setScore(score + 10);
      toast({
        title: "Correct!",
        description: "Great job! You earned 10 points.",
      });
    } else {
      toast({
        title: "Not quite!",
        description: `The correct answer was ${question.correct}`,
        variant: "destructive",
      });
    }

    setTimeout(() => {
      if (currentQuestion < guessAnimalQuestions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
        const finalScore = isCorrect ? score + 10 : score;
        saveScore.mutate({ gameType: selectedGame as string, score: finalScore });
        setShowResult(true);
      }
    }, 1500);
  };

  const resetGame = () => {
    setSelectedGame(null);
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
    setSelectedStory(null);
    setCurrentSceneId("start");
    setStoryScore(0);
    setStoryPath([]);
    setStoryComplete(false);
  };

  const currentScene = getCurrentScene();

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-chart-2/10 to-primary/5 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-chart-2 text-white">
              <Gamepad2 className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-heading text-4xl font-bold text-foreground">African Culture Games</h1>
              <p className="text-muted-foreground mt-1">
                Test your knowledge and earn rewards
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12">
        {!selectedGame ? (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="font-heading text-2xl font-bold mb-2">Choose Your Game</h2>
              <p className="text-muted-foreground">Select a game to start playing and earning points</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card
                className="p-8 cursor-pointer hover-elevate active-elevate-2 border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5"
                onClick={() => handleGameSelect("live-story")}
                data-testid="button-game-live-story"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/20 text-primary">
                    <Theater className="h-10 w-10" />
                  </div>
                  <div className="text-center">
                    <Badge className="mb-2">Featured</Badge>
                    <h3 className="font-heading text-2xl font-bold mb-2">Live the Story</h3>
                    <p className="text-muted-foreground">
                      Step into African folktales as the main character. Make choices that shape your adventure!
                    </p>
                  </div>
                  <div className="flex gap-2 flex-wrap justify-center">
                    <Badge variant="outline">{liveStories.length} Stories</Badge>
                    <Badge variant="outline">Interactive</Badge>
                  </div>
                </div>
              </Card>

              <Card
                className="p-8 cursor-pointer hover-elevate active-elevate-2 text-center"
                onClick={() => handleGameSelect("guess-animal")}
                data-testid="button-game-guess-animal"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Star className="h-8 w-8" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">Guess the Animal</h3>
                    <p className="text-sm text-muted-foreground">
                      Answer questions about animals in African folklore
                    </p>
                  </div>
                  <Badge>3 Questions</Badge>
                </div>
              </Card>

              <Card
                className="p-8 cursor-pointer hover-elevate active-elevate-2 text-center"
                onClick={() => handleGameSelect("match-proverb")}
                data-testid="button-game-match-proverb"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-accent/30 text-accent-foreground">
                    <Trophy className="h-8 w-8" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">Match the Proverb</h3>
                    <p className="text-sm text-muted-foreground">
                      Match African proverbs with their meanings
                    </p>
                  </div>
                  <Badge variant="outline">Coming Soon</Badge>
                </div>
              </Card>

              <Card
                className="p-8 cursor-pointer hover-elevate active-elevate-2 text-center"
                onClick={() => handleGameSelect("story-origin")}
                data-testid="button-game-story-origin"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-chart-2/20 text-chart-2">
                    <Gamepad2 className="h-8 w-8" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">Story Origin</h3>
                    <p className="text-sm text-muted-foreground">
                      Match stories to their countries and regions
                    </p>
                  </div>
                  <Badge variant="outline">Coming Soon</Badge>
                </div>
              </Card>
            </div>
          </div>
        ) : selectedGame === "live-story" && !selectedStory ? (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-heading text-2xl font-bold mb-2">Choose Your Adventure</h2>
                <p className="text-muted-foreground">Select a story to become the main character</p>
              </div>
              <Button variant="outline" onClick={resetGame} data-testid="button-back-to-games">
                Back to Games
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {liveStories.map((story) => (
                <Card
                  key={story.id}
                  className="overflow-hidden cursor-pointer hover-elevate active-elevate-2"
                  onClick={() => handleStorySelect(story)}
                  data-testid={`button-story-${story.id}`}
                >
                  <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20 text-primary">
                        <Theater className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-heading text-xl font-bold">{story.title}</h3>
                        <p className="text-sm text-muted-foreground">{story.region}</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground mb-4">{story.description}</p>
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline">Ages {story.ageGroup}</Badge>
                      <Badge variant="outline">Play as {story.characterName}</Badge>
                    </div>
                  </div>
                  <div className="p-4 bg-muted/30">
                    <Button className="w-full" data-testid={`button-start-${story.id}`}>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Begin Adventure
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ) : selectedGame === "live-story" && selectedStory && currentScene ? (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div>
                <Badge variant="outline" className="mb-2">{selectedStory.title}</Badge>
                <p className="text-sm text-muted-foreground">
                  Playing as <span className="font-semibold">{selectedStory.characterName}</span>, {selectedStory.characterRole}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <Badge className="text-base px-4 py-2" data-testid="badge-story-score">
                  <Sparkles className="mr-2 h-4 w-4" />
                  {storyScore} Wisdom Points
                </Badge>
                <Button variant="ghost" size="sm" onClick={resetGame} data-testid="button-exit-story">
                  Exit Story
                </Button>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex justify-between text-sm text-muted-foreground mb-2">
                <span>Story Progress</span>
                <span>{storyPath.length} / ~{Math.ceil(selectedStory.scenes.length / 2)} scenes</span>
              </div>
              <Progress value={(storyPath.length / Math.ceil(selectedStory.scenes.length / 2)) * 100} className="h-2" />
            </div>

            <Card className="overflow-hidden" data-testid="card-story-scene">
              <div className="bg-gradient-to-br from-primary/5 to-accent/5 p-6 border-b">
                <h2 className="font-heading text-2xl font-bold text-foreground" data-testid="text-scene-title">
                  {currentScene.title}
                </h2>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="prose prose-lg max-w-none">
                  <p className="text-foreground leading-relaxed text-lg" data-testid="text-scene-narrative">
                    {currentScene.narrative}
                  </p>
                </div>

                {currentScene.characterThought && (
                  <Card className="bg-primary/5 border-primary/20 p-4">
                    <p className="text-muted-foreground italic" data-testid="text-character-thought">
                      <span className="font-semibold">Your thought: </span>
                      "{currentScene.characterThought}"
                    </p>
                  </Card>
                )}

                {currentScene.isEnding ? (
                  <div className="space-y-6 pt-4">
                    <div className="text-center">
                      <div className={`inline-flex items-center gap-2 px-6 py-3 rounded-full mb-4 ${
                        currentScene.endingType === "best" ? "bg-primary/20 text-primary" :
                        currentScene.endingType === "great" ? "bg-accent/20 text-accent-foreground" :
                        "bg-muted text-muted-foreground"
                      }`}>
                        <Trophy className="h-5 w-5" />
                        <span className="font-bold text-lg capitalize">{currentScene.endingType} Ending!</span>
                      </div>
                    </div>
                    
                    <Card className="bg-gradient-to-br from-primary/10 to-accent/10 p-6">
                      <h3 className="font-heading text-xl font-bold mb-3">The Moral of the Story</h3>
                      <p className="text-lg text-foreground" data-testid="text-story-moral">
                        {currentScene.moral}
                      </p>
                    </Card>

                    <div className="flex justify-center gap-4 pt-4">
                      <Button size="lg" onClick={restartStory} data-testid="button-replay-story">
                        <RotateCcw className="mr-2 h-5 w-5" />
                        Try Different Choices
                      </Button>
                      <Button size="lg" variant="outline" onClick={() => setSelectedStory(null)} data-testid="button-choose-another">
                        Choose Another Story
                      </Button>
                      <Button size="lg" variant="ghost" onClick={resetGame} data-testid="button-back-to-games-end">
                        Back to Games
                      </Button>
                    </div>
                  </div>
                ) : currentScene.choices && (
                  <div className="space-y-4 pt-4">
                    <h3 className="font-heading text-lg font-semibold text-foreground">What do you do?</h3>
                    <div className="grid gap-3">
                      {currentScene.choices.map((choice, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          className="h-auto py-4 px-6 text-left justify-between hover-elevate"
                          onClick={() => handleStoryChoice(choice)}
                          data-testid={`button-choice-${index}`}
                        >
                          <span className="flex-1">{choice.text}</span>
                          <ArrowRight className="h-5 w-5 ml-4 shrink-0" />
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            {selectedGame === "guess-animal" && !showResult && (
              <Card className="p-8">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <Badge data-testid="badge-question-progress">Question {currentQuestion + 1} of {guessAnimalQuestions.length}</Badge>
                    <Badge variant="outline" className="text-base" data-testid="badge-current-score">
                      <Trophy className="mr-1 h-4 w-4" />
                      {score} points
                    </Badge>
                  </div>

                  <div>
                    <h2 className="font-heading text-2xl font-bold mb-6" data-testid="text-question">
                      {guessAnimalQuestions[currentQuestion].question}
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {guessAnimalQuestions[currentQuestion].options.map((option) => {
                        const isSelected = selectedAnswer === option;
                        const isCorrect = option === guessAnimalQuestions[currentQuestion].correct;
                        const showFeedback = selectedAnswer !== null;

                        return (
                          <Button
                            key={option}
                            size="lg"
                            variant={isSelected ? (isCorrect ? "default" : "destructive") : "outline"}
                            className={`h-auto py-6 text-base justify-start ${
                              showFeedback && isCorrect ? "bg-accent text-accent-foreground hover:bg-accent" : ""
                            }`}
                            onClick={() => !selectedAnswer && handleAnswer(option)}
                            disabled={selectedAnswer !== null}
                            data-testid={`button-answer-${option.toLowerCase()}`}
                          >
                            {showFeedback && isSelected && (
                              isCorrect ? 
                                <CheckCircle2 className="mr-2 h-5 w-5" /> : 
                                <XCircle className="mr-2 h-5 w-5" />
                            )}
                            {option}
                          </Button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground" data-testid="text-hint">
                      <span className="font-semibold">Hint:</span> {guessAnimalQuestions[currentQuestion].hint}
                    </p>
                  </div>
                </div>
              </Card>
            )}

            {showResult && (
              <Card className="p-12 text-center">
                <Trophy className="h-20 w-20 mx-auto mb-6 text-primary" />
                <h2 className="font-heading text-4xl font-bold mb-4" data-testid="text-final-score">
                  Game Complete!
                </h2>
                <p className="text-2xl mb-2">
                  You scored <span className="font-bold text-primary">{score}</span> points
                </p>
                <p className="text-muted-foreground mb-8">
                  Great job learning about African folklore!
                </p>
                <div className="flex gap-4 justify-center">
                  <Button size="lg" onClick={resetGame} data-testid="button-play-again">
                    Play Another Game
                  </Button>
                  <Button size="lg" variant="outline" onClick={() => handleGameSelect("guess-animal")} data-testid="button-try-again">
                    Try Again
                  </Button>
                </div>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
