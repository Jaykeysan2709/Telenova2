import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GraduationCap, Volume2, RefreshCw } from "lucide-react";
import { type LanguagePhrase } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const languages = ["Yoruba", "Swahili", "Igbo", "Zulu", "Hausa"] as const;

export default function Learn() {
  const [selectedLanguage, setSelectedLanguage] = useState<typeof languages[number]>("Yoruba");
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const { toast } = useToast();

  const { data: phrases, isLoading } = useQuery<LanguagePhrase[]>({
    queryKey: ["/api/phrases", selectedLanguage],
  });

  const { data: dailyWord } = useQuery<LanguagePhrase>({
    queryKey: ["/api/phrases/daily"],
  });

  const currentPhrase = phrases?.[currentCardIndex];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentCardIndex((prev) => (phrases ? (prev + 1) % phrases.length : 0));
  };

  const handlePrevious = () => {
    setIsFlipped(false);
    setCurrentCardIndex((prev) => (phrases ? (prev - 1 + phrases.length) % phrases.length : 0));
  };

  const playAudio = (phrase: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    
    toast({
      title: "Audio Coming Soon! 🎧",
      description: "Native audio pronunciation for African languages is currently in development.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-accent/10 to-primary/5 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-heading text-4xl font-bold text-foreground">Language Learning</h1>
              <p className="text-muted-foreground mt-1">
                Master African languages one phrase at a time
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-12">
        {dailyWord && (
          <Card className="p-8 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <Badge className="mb-4 text-xs" data-testid="badge-word-of-day">Word of the Day</Badge>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="font-heading text-3xl font-bold" data-testid="text-daily-word">
                    {dailyWord.phrase}
                  </h2>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => playAudio(dailyWord.phrase)}
                    data-testid="button-play-daily-audio"
                  >
                    <Volume2 className="h-5 w-5" />
                  </Button>
                </div>
                <p className="text-muted-foreground text-sm mb-1">
                  Pronunciation: <span className="font-semibold">{dailyWord.pronunciation}</span>
                </p>
                <Badge variant="outline" className="text-xs" data-testid="badge-daily-language">{dailyWord.language}</Badge>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-lg text-foreground" data-testid="text-daily-translation">
                  Translation: <span className="font-semibold">{dailyWord.translation}</span>
                </p>
              </div>
            </div>
          </Card>
        )}

        <div>
          <h2 className="font-heading text-2xl font-bold mb-6">Practice Flashcards</h2>
          
          <Tabs value={selectedLanguage} onValueChange={(val) => {
            setSelectedLanguage(val as typeof languages[number]);
            setCurrentCardIndex(0);
            setIsFlipped(false);
          }}>
            <TabsList className="mb-6 grid w-full grid-cols-5 gap-2">
              {languages.map((lang) => (
                <TabsTrigger
                  key={lang}
                  value={lang}
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  data-testid={`tab-${lang.toLowerCase()}`}
                >
                  {lang}
                </TabsTrigger>
              ))}
            </TabsList>

            {languages.map((lang) => (
              <TabsContent key={lang} value={lang} className="mt-0">
                {isLoading ? (
                  <Card className="p-12">
                    <Skeleton className="h-32 w-full mb-4" />
                    <Skeleton className="h-10 w-1/2 mx-auto" />
                  </Card>
                ) : phrases && phrases.length > 0 && currentPhrase ? (
                  <div className="space-y-6">
                    <div className="text-center text-sm text-muted-foreground" data-testid="text-card-progress">
                      Card {currentCardIndex + 1} of {phrases.length}
                    </div>

                    <Card
                      className={`min-h-[300px] cursor-pointer transition-all duration-300 hover-elevate active-elevate-2 ${
                        isFlipped ? "bg-gradient-to-br from-accent/10 to-primary/5" : ""
                      }`}
                      onClick={() => setIsFlipped(!isFlipped)}
                      data-testid="card-flashcard"
                    >
                      <div className="p-12 h-full flex flex-col items-center justify-center text-center">
                        {!isFlipped ? (
                          <div className="space-y-4">
                            <Badge variant="outline" data-testid="badge-phrase-category">{currentPhrase.category}</Badge>
                            <h3 className="font-heading text-4xl md:text-5xl font-bold" data-testid="text-phrase">
                              {currentPhrase.phrase}
                            </h3>
                            <div className="flex items-center justify-center gap-2">
                              <p className="text-muted-foreground" data-testid="text-pronunciation">
                                {currentPhrase.pronunciation}
                              </p>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={(e) => playAudio(currentPhrase.phrase, e)}
                                className="hover-elevate"
                                data-testid="button-play-phrase-audio"
                              >
                                <Volume2 className="h-5 w-5" />
                              </Button>
                            </div>
                            <p className="text-sm text-muted-foreground pt-4">
                              Click to see translation
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <Badge className="bg-primary">Translation</Badge>
                            <h3 className="font-heading text-4xl md:text-5xl font-bold" data-testid="text-translation">
                              {currentPhrase.translation}
                            </h3>
                            <p className="text-sm text-muted-foreground pt-4">
                              Click to flip back
                            </p>
                          </div>
                        )}
                      </div>
                    </Card>

                    <div className="flex gap-4 justify-center">
                      <Button
                        variant="outline"
                        onClick={handlePrevious}
                        disabled={phrases.length <= 1}
                        data-testid="button-previous"
                      >
                        Previous
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setIsFlipped(!isFlipped)}
                        data-testid="button-flip"
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Flip Card
                      </Button>
                      <Button
                        onClick={handleNext}
                        disabled={phrases.length <= 1}
                        data-testid="button-next"
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Card className="p-12 text-center">
                    <GraduationCap className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="font-heading text-xl font-bold mb-2">No phrases available</h3>
                    <p className="text-muted-foreground">
                      Check back later for {lang} learning materials
                    </p>
                  </Card>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </div>
  );
}
