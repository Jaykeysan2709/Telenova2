import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  BookOpen, 
  Gamepad2, 
  Languages, 
  GraduationCap, 
  Users, 
  Heart, 
  Globe, 
  Sparkles,
  Target,
  Lightbulb,
  BookMarked,
  Theater
} from "lucide-react";

export default function About() {
  const productOfferings = [
    {
      icon: BookMarked,
      title: "Digital Story Library",
      description: "A rich collection featuring African folktales and wisdom stories from across the continent. Explore tales of Anansi the Spider, the origins of the baobab tree, stories of Mami Wata, and many more age-old narratives passed down through generations.",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: Theater,
      title: '"Live the Story" Interactive Gameplay',
      description: "Children step into stories as main characters, making choices that shape the narrative. This immersive experience helps young learners connect deeply with African heritage while developing critical thinking and decision-making skills.",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: Languages,
      title: "Cultural Learning Tools",
      description: "Comprehensive learning resources including language snippets from Yoruba, Swahili, Igbo, Zulu, and Hausa. Features proverbs with meanings, pronunciation guides, and character development activities rooted in African values.",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: GraduationCap,
      title: "Story Packs & Educational Bundles",
      description: "Curated collections designed for schools and cultural programmes. Each bundle includes themed stories, lesson plans, activities, and assessment tools aligned with educational standards for different age groups.",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: Users,
      title: "Workshops and Community Activities",
      description: "Engaging programmes delivered through partners including schools, libraries, cultural centers, and community organizations. Interactive sessions bring African storytelling to life through drama, art, and collaborative learning.",
      color: "text-primary",
      bgColor: "bg-primary/10"
    }
  ];

  const values = [
    {
      icon: Heart,
      title: "Cultural Preservation",
      description: "We believe African stories are treasures that deserve to be preserved and shared with future generations."
    },
    {
      icon: Sparkles,
      title: "Joyful Learning",
      description: "Learning about heritage should be fun, engaging, and spark curiosity in young minds."
    },
    {
      icon: Globe,
      title: "Global Connection",
      description: "We connect children across the African diaspora with their roots, no matter where they are in the world."
    },
    {
      icon: Target,
      title: "Age-Appropriate Content",
      description: "Every story and activity is carefully crafted for children ages 4-13, ensuring safe and suitable content."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/20 via-accent/10 to-background">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,150,50,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(100,200,100,0.1),transparent_50%)]" />
        
        <div className="relative max-w-5xl mx-auto px-6 py-16 md:py-20">
          <div className="text-center space-y-6">
            <Badge className="text-sm px-4 py-1.5" data-testid="badge-about">
              About Us
            </Badge>
            <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-foreground tracking-tight" data-testid="text-about-title">
              Welcome to{" "}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Tale-Nova
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed italic" data-testid="text-about-tagline">
              "telling old african stories in a new way"
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12 space-y-16">
        <section className="space-y-6" data-testid="section-mission">
          <div className="text-center space-y-4">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
              Our Mission
            </h2>
            <div className="max-w-3xl mx-auto space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                Tale-Nova is an educational storytelling platform designed for children ages 4-13 
                in the African diaspora and across Africa. We connect young learners with the rich 
                tapestry of African folklore, languages, and cultural wisdom through fun, immersive, 
                and AI-powered storytelling experiences.
              </p>
              <p>
                Our platform bridges generations, bringing timeless tales of courage, wisdom, and 
                wonder to children growing up in a digital age. Through interactive stories, language 
                learning, educational games, and cultural exploration, we help children develop a 
                strong sense of identity and pride in their African heritage.
              </p>
            </div>
          </div>
        </section>

        <section className="space-y-8" data-testid="section-offerings">
          <div className="text-center space-y-4">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
              What We Offer
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive tools and experiences for cultural learning and engagement
            </p>
          </div>

          <div className="space-y-6">
            {productOfferings.map((offering, index) => (
              <Card key={index} className="overflow-hidden hover-elevate" data-testid={`card-offering-${index}`}>
                <div className="flex flex-col md:flex-row">
                  <div className={`${offering.bgColor} p-6 md:p-8 flex items-center justify-center md:w-48 shrink-0`}>
                    <offering.icon className={`h-12 w-12 ${offering.color}`} />
                  </div>
                  <div className="p-6 md:p-8 flex-1">
                    <h3 className="font-heading text-xl md:text-2xl font-bold text-foreground mb-3">
                      {offering.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {offering.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-8" data-testid="section-values">
          <div className="text-center space-y-4">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
              Our Values
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="p-6 hover-elevate" data-testid={`card-value-${index}`}>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <value.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-foreground mb-2">
                      {value.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        <section className="space-y-8" data-testid="section-features">
          <div className="text-center space-y-4">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground">
              Platform Features
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need for an enriching cultural learning experience
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6 text-center hover-elevate" data-testid="card-feature-stories">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <BookOpen className="h-7 w-7 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Story Library</h3>
              <p className="text-muted-foreground text-sm">
                Hundreds of authentic African folktales from diverse regions and cultures
              </p>
            </Card>

            <Card className="p-6 text-center hover-elevate" data-testid="card-feature-ai">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center">
                <Sparkles className="h-7 w-7 text-accent" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">AI Story Builder</h3>
              <p className="text-muted-foreground text-sm">
                Create personalized stories with AI that respects cultural authenticity
              </p>
            </Card>

            <Card className="p-6 text-center hover-elevate" data-testid="card-feature-languages">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Languages className="h-7 w-7 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Language Learning</h3>
              <p className="text-muted-foreground text-sm">
                Interactive lessons in Yoruba, Swahili, Igbo, Zulu, and Hausa
              </p>
            </Card>

            <Card className="p-6 text-center hover-elevate" data-testid="card-feature-games">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center">
                <Gamepad2 className="h-7 w-7 text-accent" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Educational Games</h3>
              <p className="text-muted-foreground text-sm">
                Fun games that reinforce cultural knowledge and language skills
              </p>
            </Card>

            <Card className="p-6 text-center hover-elevate" data-testid="card-feature-map">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Globe className="h-7 w-7 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Cultural Map</h3>
              <p className="text-muted-foreground text-sm">
                Explore Africa's diverse cultures, stories, and languages by region
              </p>
            </Card>

            <Card className="p-6 text-center hover-elevate" data-testid="card-feature-proverbs">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center">
                <Lightbulb className="h-7 w-7 text-accent" />
              </div>
              <h3 className="font-heading text-lg font-bold mb-2">Proverbs & Wisdom</h3>
              <p className="text-muted-foreground text-sm">
                Daily proverbs and wisdom sayings from across the African continent
              </p>
            </Card>
          </div>
        </section>

        <section className="text-center space-y-6 py-8" data-testid="section-cta">
          <Card className="p-8 md:p-12 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-4">
              Ready to Begin the Adventure?
            </h2>
            <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
              Join thousands of children discovering the magic of African storytelling. 
              Start exploring stories, learning languages, and connecting with your heritage today.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/stories" data-testid="button-explore-stories">
                  <BookOpen className="mr-2 h-5 w-5" />
                  Explore Stories
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/story-builder" data-testid="button-create-story">
                  <Sparkles className="mr-2 h-5 w-5" />
                  Create Your Story
                </Link>
              </Button>
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
}
