import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Map as MapIcon, BookOpen } from "lucide-react";
import { Link } from "wouter";

const africanCountries = [
  { name: "Nigeria", region: "West Africa", stories: 5, languages: "Yoruba, Igbo, Hausa" },
  { name: "Kenya", region: "East Africa", stories: 3, languages: "Swahili, Kikuyu" },
  { name: "South Africa", region: "Southern Africa", stories: 4, languages: "Zulu, Xhosa" },
  { name: "Ghana", region: "West Africa", stories: 6, languages: "Akan, Ga" },
  { name: "Egypt", region: "North Africa", stories: 2, languages: "Arabic" },
  { name: "Ethiopia", region: "East Africa", stories: 3, languages: "Amharic, Oromo" },
  { name: "Tanzania", region: "East Africa", stories: 2, languages: "Swahili" },
  { name: "Zimbabwe", region: "Southern Africa", stories: 3, languages: "Shona, Ndebele" },
];

export default function MapPage() {
  const [selectedCountry, setSelectedCountry] = useState<typeof africanCountries[0] | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-primary/10 to-accent/5 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <MapIcon className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-heading text-4xl font-bold text-foreground">Cultural Map of Africa</h1>
              <p className="text-muted-foreground mt-1">
                Explore stories and cultures from across the continent
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <Card className="p-8">
              <h2 className="font-heading text-2xl font-bold mb-6">African Countries</h2>
              <p className="text-sm text-muted-foreground mb-6">
                Click on a country to learn about its stories and cultural heritage
              </p>
              <div className="space-y-3">
                {africanCountries.map((country) => (
                  <Card
                    key={country.name}
                    className={`p-4 cursor-pointer transition-all hover-elevate active-elevate-2 ${
                      selectedCountry?.name === country.name ? "bg-primary/10 border-primary" : ""
                    }`}
                    onClick={() => setSelectedCountry(country)}
                    data-testid={`button-country-${country.name.toLowerCase().replace(' ', '-')}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="font-heading text-lg font-bold">{country.name}</h3>
                        <p className="text-sm text-muted-foreground">{country.region}</p>
                      </div>
                      <Badge variant="secondary" data-testid={`badge-story-count-${country.name.toLowerCase().replace(' ', '-')}`}>{country.stories} stories</Badge>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          </div>

          <div>
            {selectedCountry ? (
              <Card className="p-8 sticky top-6">
                <div className="space-y-6">
                  <div>
                    <Badge className="mb-4" data-testid="badge-selected-region">{selectedCountry.region}</Badge>
                    <h2 className="font-heading text-3xl font-bold mb-2" data-testid="text-country-name">
                      {selectedCountry.name}
                    </h2>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Available Stories</h3>
                      <p className="text-muted-foreground" data-testid="text-stories-available">
                        Discover {selectedCountry.stories} unique {selectedCountry.stories === 1 ? 'tale' : 'tales'} from {selectedCountry.name}
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold text-lg mb-2">Languages</h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedCountry.languages.split(", ").map((lang, index) => (
                          <Badge key={lang} variant="outline" data-testid={`badge-language-${index}`}>{lang}</Badge>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4">
                      <h3 className="font-semibold text-lg mb-3">Cultural Highlights</h3>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-start gap-2">
                          <span className="text-primary mt-1">•</span>
                          <span>Rich oral storytelling traditions passed down through generations</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary mt-1">•</span>
                          <span>Unique folklore featuring local animals and natural landscapes</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-primary mt-1">•</span>
                          <span>Proverbs and wisdom that guide community values</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <Button className="w-full" size="lg" asChild>
                    <Link href="/stories" data-testid="button-explore-stories">
                      <BookOpen className="mr-2 h-5 w-5" />
                      Explore Stories from {selectedCountry.name}
                    </Link>
                  </Button>
                </div>
              </Card>
            ) : (
              <Card className="p-12 text-center h-full flex flex-col items-center justify-center">
                <MapIcon className="h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="font-heading text-xl font-bold mb-2">Select a Country</h3>
                <p className="text-muted-foreground">
                  Click on any country to discover its stories and cultural heritage
                </p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
