import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Sparkles, Wand2, Loader2 } from "lucide-react";
import { type AIStoryRequest, type AIStoryResponse, aiStoryRequestSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

const characters = [
  "Anansi the Spider",
  "Clever Tortoise",
  "Wise Elephant",
  "Swift Cheetah",
  "Cunning Hare",
  "Brave Lion",
  "Magical Bird",
  "Mighty Leopard",
  "Gentle Giraffe",
  "Playful Monkey",
  "Sacred Crocodile",
  "Mysterious Hyena",
  "Noble Eagle",
  "Cunning Fox",
  "Powerful Buffalo",
  "Graceful Gazelle",
  "Ancient Baobab Tree",
  "Singing Nightingale",
  "Clever Mongoose",
  "Proud Peacock",
];

const morals = [
  "The importance of honesty",
  "Working together is stronger",
  "Kindness brings rewards",
  "Wisdom over strength",
  "Respect for elders",
  "Patience leads to success",
  "Courage in difficult times",
  "Pride comes before a fall",
  "Share your blessings with others",
  "Listen before you speak",
  "True beauty comes from within",
  "Hard work brings prosperity",
  "Don't judge by appearances",
  "Forgiveness heals the heart",
  "Greed leads to loss",
  "Unity makes us stronger",
  "Keep your promises",
  "Learn from your mistakes",
  "Humility is a virtue",
  "Creativity solves problems",
];

const themes = [
  "Adventure in the Savanna",
  "Village Life",
  "Royal Palace",
  "Magical Forest",
  "River Journey",
  "Mountain Quest",
  "Desert Crossing",
  "Ancient Marketplace",
  "Moonlit Ceremony",
  "Sacred Waterfall",
  "Harvest Festival",
  "Rainy Season",
  "Starlit Night",
  "Great Migration",
  "Hidden Cave",
  "Fishing Village",
  "Drum Circle Gathering",
  "Baobab Grove",
  "Golden Sunset Plains",
  "Secret Garden",
];

const supportingCharacters = [
  "Wise Elder",
  "Mischievous Child",
  "Village Chief",
  "Mysterious Stranger",
  "Helpful Friend",
  "Talking River Spirit",
  "Ancient Ancestor",
  "Forest Guardian",
  "Market Vendor",
  "Fellow Traveler",
];

const storyTones = [
  "Adventurous and Exciting",
  "Humorous and Playful",
  "Wise and Thoughtful",
  "Mysterious and Intriguing",
  "Heartwarming and Gentle",
  "Inspiring and Uplifting",
];

const specialElements = [
  "A magical object",
  "An ancient proverb",
  "A traditional song",
  "A wise riddle",
  "A special ceremony",
  "A hidden treasure",
  "A prophetic dream",
  "A talking animal guide",
];

const timesOfDay = [
  "Dawn (early morning)",
  "Midday (bright sunshine)",
  "Sunset (golden hour)",
  "Night (under the stars)",
  "Full moon night",
];

const conflicts = [
  "Solving a mystery",
  "Overcoming a fear",
  "Helping someone in need",
  "Finding something lost",
  "Making a difficult choice",
  "Proving one's worth",
  "Breaking a curse",
  "Uniting divided groups",
];

export default function StoryBuilder() {
  const [generatedStory, setGeneratedStory] = useState<AIStoryResponse | null>(null);
  const { toast } = useToast();

  const form = useForm<AIStoryRequest>({
    resolver: zodResolver(aiStoryRequestSchema),
    defaultValues: {
      character: "",
      moral: "",
      theme: "",
      ageGroup: "8-10",
      supportingCharacter: "",
      storyTone: "",
      specialElement: "",
      timeOfDay: "",
      conflict: "",
    },
  });

  const generateStory = useMutation({
    mutationFn: async (data: AIStoryRequest) => {
      const response = await apiRequest("POST", "/api/stories/generate", data);
      const jsonData = await response.json();
      if (!response.ok) {
        throw new Error(jsonData.error || "Failed to generate story");
      }
      return jsonData as AIStoryResponse;
    },
    onSuccess: (data) => {
      setGeneratedStory(data);
      toast({
        title: "Story Created!",
        description: "Your unique African tale has been generated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate story. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AIStoryRequest) => {
    generateStory.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-primary/10 via-accent/5 to-background border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-heading text-4xl font-bold text-foreground">AI Story Builder</h1>
              <p className="text-muted-foreground mt-1">
                Create your own unique African folktale
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <Card className="p-8">
              <div className="space-y-6">
                <div>
                  <h2 className="font-heading text-2xl font-bold mb-2">Build Your Story</h2>
                  <p className="text-sm text-muted-foreground">
                    Choose your favorite elements and watch the magic happen
                  </p>
                </div>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="character"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Main Character</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-character">
                                <SelectValue placeholder="Choose a character" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {characters.map((char) => (
                                <SelectItem 
                                  key={char} 
                                  value={char}
                                  data-testid={`option-character-${char.toLowerCase().replace(/\s+/g, '-')}`}
                                >
                                  {char}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="moral"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Moral Lesson</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-moral">
                                <SelectValue placeholder="Choose a lesson" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {morals.map((moral, index) => (
                                <SelectItem 
                                  key={moral} 
                                  value={moral}
                                  data-testid={`option-moral-${index}`}
                                >
                                  {moral}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="theme"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Story Setting</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-theme">
                                <SelectValue placeholder="Choose a setting" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {themes.map((theme, index) => (
                                <SelectItem 
                                  key={theme} 
                                  value={theme}
                                  data-testid={`option-theme-${index}`}
                                >
                                  {theme}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="ageGroup"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">Age Group</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-age-group">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="4-7" data-testid="option-age-4-7">Ages 4-7 (Younger)</SelectItem>
                              <SelectItem value="8-10" data-testid="option-age-8-10">Ages 8-10 (Middle)</SelectItem>
                              <SelectItem value="11-13" data-testid="option-age-11-13">Ages 11-13 (Older)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="pt-4 border-t border-border">
                      <h3 className="text-sm font-semibold text-muted-foreground mb-4">Optional Elements (add more details)</h3>
                      
                      <div className="space-y-6">
                        <FormField
                          control={form.control}
                          name="supportingCharacter"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Supporting Character</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-supporting-character">
                                    <SelectValue placeholder="Optional: Add a companion" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {supportingCharacters.map((char) => (
                                    <SelectItem key={char} value={char}>
                                      {char}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="storyTone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Story Tone</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-story-tone">
                                    <SelectValue placeholder="Optional: Set the mood" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {storyTones.map((tone) => (
                                    <SelectItem key={tone} value={tone}>
                                      {tone}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="specialElement"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Special Element</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-special-element">
                                    <SelectValue placeholder="Optional: Add something unique" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {specialElements.map((element) => (
                                    <SelectItem key={element} value={element}>
                                      {element}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="timeOfDay"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Time of Day</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-time-of-day">
                                    <SelectValue placeholder="Optional: Choose when it happens" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {timesOfDay.map((time) => (
                                    <SelectItem key={time} value={time}>
                                      {time}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="conflict"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Story Challenge</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-conflict">
                                    <SelectValue placeholder="Optional: What challenge to face" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {conflicts.map((conflict) => (
                                    <SelectItem key={conflict} value={conflict}>
                                      {conflict}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full h-12 text-base font-semibold"
                      disabled={generateStory.isPending}
                      data-testid="button-generate-story"
                    >
                      {generateStory.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Creating Your Story...
                        </>
                      ) : (
                        <>
                          <Wand2 className="mr-2 h-5 w-5" />
                          Generate Story
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </div>
            </Card>
          </div>

          <div>
            {generatedStory ? (
              <Card className="p-8 bg-gradient-to-br from-primary/5 to-accent/5">
                <div className="space-y-6">
                  <div className="flex items-center gap-2">
                    <Badge className="text-xs">Your Story</Badge>
                  </div>

                  <div>
                    <h2 className="font-heading text-3xl font-bold text-foreground mb-4" data-testid="text-generated-title">
                      {generatedStory.title}
                    </h2>
                    <div className="prose prose-lg max-w-none">
                      <p className="text-base leading-relaxed text-foreground whitespace-pre-line" data-testid="text-generated-content">
                        {generatedStory.content}
                      </p>
                    </div>
                  </div>

                  <Card className="p-6 bg-primary/10 border-primary/20">
                    <h3 className="font-heading text-xl font-bold mb-2">Moral</h3>
                    <p className="text-foreground" data-testid="text-generated-moral">
                      {generatedStory.moral}
                    </p>
                  </Card>

                  <Card className="p-6 bg-accent/20 border-accent/30">
                    <h3 className="font-heading text-xl font-bold mb-2">Cultural Context</h3>
                    <p className="text-foreground text-sm" data-testid="text-generated-context">
                      {generatedStory.culturalContext}
                    </p>
                  </Card>

                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full"
                    onClick={() => setGeneratedStory(null)}
                    data-testid="button-create-another"
                  >
                    Create Another Story
                  </Button>
                </div>
              </Card>
            ) : (
              <Card className="p-12 text-center h-full flex flex-col items-center justify-center">
                <Sparkles className="h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="font-heading text-xl font-bold mb-2">Your Story Will Appear Here</h3>
                <p className="text-muted-foreground">
                  Fill out the form and click "Generate Story" to create your unique African tale
                </p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
