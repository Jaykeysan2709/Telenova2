import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { User, Trophy, BookOpen, Star, Flame } from "lucide-react";
import { type UserProgress, type Badge as BadgeType } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function ProgressPage() {
  const { data: progress, isLoading: progressLoading } = useQuery<UserProgress>({
    queryKey: ["/api/progress"],
  });

  const { data: badges, isLoading: badgesLoading } = useQuery<BadgeType[]>({
    queryKey: ["/api/badges"],
  });

  const earnedBadges = badges?.filter((badge) => 
    progress?.badges.includes(badge.id)
  ) || [];

  const unearnedBadges = badges?.filter((badge) => 
    !progress?.badges.includes(badge.id)
  ) || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-primary/10 to-accent/5 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <User className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-heading text-4xl font-bold text-foreground">My Progress</h1>
              <p className="text-muted-foreground mt-1">
                Track your learning journey
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-8">
        {progressLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-6">
                <Skeleton className="h-6 w-full mb-4" />
                <Skeleton className="h-12 w-24" />
              </Card>
            ))}
          </div>
        ) : progress ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-muted-foreground">Total Points</h3>
                  <Trophy className="h-5 w-5 text-primary" />
                </div>
                <p className="text-4xl font-heading font-bold text-foreground" data-testid="text-total-points">
                  {progress.points}
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Keep learning to earn more!
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-muted-foreground">Stories Read</h3>
                  <BookOpen className="h-5 w-5 text-accent-foreground" />
                </div>
                <p className="text-4xl font-heading font-bold text-foreground" data-testid="text-stories-completed">
                  {progress.completedStories.length}
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Discover more tales
                </p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-muted-foreground">Current Streak</h3>
                  <Flame className="h-5 w-5 text-chart-3" />
                </div>
                <p className="text-4xl font-heading font-bold text-foreground" data-testid="text-current-streak">
                  {progress.currentStreak} days
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Keep it going!
                </p>
              </Card>
            </div>

            <div>
              <h2 className="font-heading text-2xl font-bold mb-6">Learning Progress</h2>
              <Card className="p-6">
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Stories Completed</span>
                      <span className="text-sm text-muted-foreground" data-testid="text-stories-progress">
                        {progress.completedStories.length} / 20
                      </span>
                    </div>
                    <Progress value={(progress.completedStories.length / 20) * 100} className="h-2" data-testid="progress-stories" />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Points to Next Badge</span>
                      <span className="text-sm text-muted-foreground" data-testid="text-points-progress">
                        {progress.points} / 100
                      </span>
                    </div>
                    <Progress value={(progress.points % 100)} className="h-2" data-testid="progress-points" />
                  </div>
                </div>
              </Card>
            </div>

            <div>
              <h2 className="font-heading text-2xl font-bold mb-6">Earned Badges</h2>
              {badgesLoading ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[1, 2, 3, 4].map((i) => (
                    <Card key={i} className="p-6">
                      <Skeleton className="h-16 w-16 mx-auto rounded-full mb-4" />
                      <Skeleton className="h-4 w-full" />
                    </Card>
                  ))}
                </div>
              ) : earnedBadges.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {earnedBadges.map((badge) => (
                    <Card key={badge.id} className="p-6 text-center" data-testid={`badge-earned-${badge.id}`}>
                      <div className="flex h-16 w-16 mx-auto mb-4 items-center justify-center rounded-full bg-primary/10 text-primary">
                        <Star className="h-8 w-8" />
                      </div>
                      <h3 className="font-heading font-bold mb-1" data-testid={`text-badge-name-${badge.id}`}>{badge.name}</h3>
                      <p className="text-xs text-muted-foreground" data-testid={`text-badge-desc-${badge.id}`}>{badge.description}</p>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-12 text-center">
                  <Trophy className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-heading text-xl font-bold mb-2">No Badges Yet</h3>
                  <p className="text-muted-foreground">
                    Complete stories and games to earn your first badge!
                  </p>
                </Card>
              )}
            </div>

            {unearnedBadges.length > 0 && (
              <div>
                <h2 className="font-heading text-2xl font-bold mb-6">Available Badges</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {unearnedBadges.slice(0, 4).map((badge) => (
                    <Card key={badge.id} className="p-6 text-center opacity-60" data-testid={`badge-unearned-${badge.id}`}>
                      <div className="flex h-16 w-16 mx-auto mb-4 items-center justify-center rounded-full bg-muted">
                        <Star className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <h3 className="font-heading font-bold mb-1 text-sm" data-testid={`text-unearned-name-${badge.id}`}>{badge.name}</h3>
                      <p className="text-xs text-muted-foreground mb-2" data-testid={`text-unearned-desc-${badge.id}`}>{badge.description}</p>
                      <Badge variant="outline" className="text-xs" data-testid={`badge-requirement-${badge.id}`}>{badge.requirement}</Badge>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <Card className="p-12 text-center">
            <User className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="font-heading text-xl font-bold mb-2">Start Your Journey</h3>
            <p className="text-muted-foreground">
              Read stories and play games to track your progress
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
