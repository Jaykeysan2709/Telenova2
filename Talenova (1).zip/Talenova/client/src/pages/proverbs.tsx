import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Lightbulb, Sparkles, Globe } from "lucide-react";
import { type Proverb } from "@shared/schema";

export default function Proverbs() {
  const { data: proverbs, isLoading } = useQuery<Proverb[]>({
    queryKey: ["/api/proverbs"],
  });

  const { data: dailyProverb } = useQuery<Proverb>({
    queryKey: ["/api/proverbs/daily"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <Skeleton className="h-12 w-96 mb-8" />
          <Skeleton className="h-64 w-full mb-8" />
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/20 via-accent/10 to-background">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,150,50,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(100,200,100,0.1),transparent_50%)]" />
        
        <div className="relative max-w-6xl mx-auto px-6 py-16">
          <div className="text-center space-y-4">
            <Badge className="text-sm px-4 py-1.5">
              <Lightbulb className="h-4 w-4 mr-2" />
              African Wisdom
            </Badge>
            <h1 className="font-heading text-5xl md:text-6xl font-bold text-foreground tracking-tight">
              Proverbs & Wisdom
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Discover the timeless wisdom passed down through generations of African cultures
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-12">
        {dailyProverb && (
          <section>
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="h-6 w-6 text-primary" />
              <h2 className="font-heading text-3xl font-bold text-foreground">
                Proverb of the Day
              </h2>
            </div>
            <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <CardTitle className="text-2xl md:text-3xl font-heading leading-relaxed mb-4">
                      "{dailyProverb.proverb}"
                    </CardTitle>
                    <CardDescription className="text-base md:text-lg leading-relaxed">
                      {dailyProverb.meaning}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary" className="gap-1.5">
                    <Globe className="h-3.5 w-3.5" />
                    {dailyProverb.culture}
                  </Badge>
                  <Badge variant="outline" data-testid={`badge-category-${dailyProverb.id}`}>
                    {dailyProverb.category}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        <section>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-heading text-3xl font-bold text-foreground">
                All Proverbs
              </h2>
              <p className="text-muted-foreground mt-1">
                {proverbs?.length || 0} proverbs from across Africa
              </p>
            </div>
          </div>

          {proverbs && proverbs.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {proverbs.map((proverb) => (
                <Card
                  key={proverb.id}
                  className="hover-elevate transition-all"
                  data-testid={`card-proverb-${proverb.id}`}
                >
                  <CardHeader>
                    <CardTitle className="text-lg font-heading leading-relaxed">
                      "{proverb.proverb}"
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {proverb.meaning}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="text-xs gap-1">
                        <Globe className="h-3 w-3" />
                        {proverb.culture}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {proverb.category}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Lightbulb className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  No proverbs found. Check back soon for more wisdom!
                </p>
              </CardContent>
            </Card>
          )}
        </section>
      </div>
    </div>
  );
}
