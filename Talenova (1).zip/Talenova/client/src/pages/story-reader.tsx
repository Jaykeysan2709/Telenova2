import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Star, Globe2, Heart } from "lucide-react";
import { type Story } from "@shared/schema";

export default function StoryReader() {
  const [, params] = useRoute("/stories/:id");
  const storyId = params?.id;

  const { data: story, isLoading } = useQuery<Story>({
    queryKey: ["/api/stories", storyId],
    enabled: !!storyId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-12 w-3/4" />
          <Skeleton className="h-6 w-1/2" />
          <div className="space-y-4 mt-8">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
          </div>
        </div>
      </div>
    );
  }

  if (!story) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card className="p-12 text-center max-w-md">
          <h2 className="font-heading text-2xl font-bold mb-4">Story Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The story you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link href="/stories" data-testid="button-back">Back to Stories</Link>
          </Button>
        </Card>
      </div>
    );
  }

  const difficultyStars = Array.from({ length: 3 }, (_, i) => i < story.difficulty);

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-primary/10 to-accent/5 border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <Button
            variant="ghost"
            asChild
            className="mb-6"
          >
            <Link href="/stories" data-testid="button-back-to-stories">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Stories
            </Link>
          </Button>

          <div className="space-y-6">
            <div>
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="secondary" data-testid={`badge-region-${story.id}`}>
                  <Globe2 className="mr-1 h-3 w-3" />
                  {story.region}
                </Badge>
                <Badge variant="outline" data-testid={`badge-age-${story.id}`}>
                  Ages {story.ageGroup}
                </Badge>
                <Badge className="bg-accent text-accent-foreground" data-testid={`badge-category-${story.id}`}>
                  {story.category}
                </Badge>
                <Badge variant="outline" data-testid={`badge-difficulty-${story.id}`}>
                  <div className="flex gap-1 items-center">
                    {difficultyStars.map((filled, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          filled ? "fill-primary text-primary" : "text-muted"
                        }`}
                      />
                    ))}
                  </div>
                </Badge>
              </div>

              <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4" data-testid="text-story-title">
                {story.title}
              </h1>

              <p className="text-lg text-muted-foreground">
                A tale from {story.country} featuring {story.character}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="space-y-8">
          <Card className="p-8 md:p-12">
            <div className="prose prose-lg max-w-none">
              <div className="text-lg leading-relaxed text-foreground whitespace-pre-line" data-testid="text-story-content">
                {story.content}
              </div>
            </div>
          </Card>

          <Card className="p-8 bg-primary/5 border-primary/20">
            <h3 className="font-heading text-2xl font-bold mb-4 flex items-center gap-2">
              <Heart className="h-6 w-6 text-primary" />
              Moral of the Story
            </h3>
            <p className="text-lg text-foreground leading-relaxed" data-testid="text-story-moral">
              {story.moral}
            </p>
          </Card>

          <Card className="p-8 bg-accent/10 border-accent/20">
            <h3 className="font-heading text-2xl font-bold mb-4">Cultural Context</h3>
            <p className="text-foreground leading-relaxed" data-testid="text-cultural-context">
              {story.culturalContext}
            </p>
          </Card>

          <div className="flex gap-4 justify-center pt-6">
            <Button size="lg" asChild>
              <Link href="/stories" data-testid="button-read-more">Read More Stories</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/story-builder" data-testid="button-create-your-own">Create Your Own</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
