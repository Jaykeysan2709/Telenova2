import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen } from "lucide-react";
import { Link } from "wouter";
import { type Story } from "@shared/schema";
import { StoryCard } from "@/components/story-card";
import { Skeleton } from "@/components/ui/skeleton";

export default function Stories() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedAgeGroup, setSelectedAgeGroup] = useState<string>("all");

  const { data: stories, isLoading } = useQuery<Story[]>({
    queryKey: ["/api/stories"],
  });

  const filteredStories = stories?.filter((story) => {
    const categoryMatch = selectedCategory === "all" || story.category === selectedCategory;
    const ageMatch = selectedAgeGroup === "all" || story.ageGroup === selectedAgeGroup;
    return categoryMatch && ageMatch;
  });

  const categories = ["all", "folklore", "mythology", "legend", "fable"];
  const ageGroups = ["all", "4-7", "8-10", "11-13"];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-br from-primary/10 to-accent/5 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <BookOpen className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-heading text-4xl font-bold text-foreground">Story Library</h1>
              <p className="text-muted-foreground mt-1">
                Discover authentic African folklore and legends
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex flex-wrap gap-2">
              <span className="text-sm font-medium text-muted-foreground">Category:</span>
              {categories.map((cat) => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(cat)}
                  data-testid={`button-category-${cat}`}
                  className="capitalize"
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium text-muted-foreground">Age Group:</span>
            {ageGroups.map((age) => (
              <Badge
                key={age}
                variant={selectedAgeGroup === age ? "default" : "outline"}
                className="cursor-pointer hover-elevate px-3 py-1"
                onClick={() => setSelectedAgeGroup(age)}
                data-testid={`badge-age-${age}`}
              >
                {age === "all" ? "All Ages" : `Ages ${age}`}
              </Badge>
            ))}
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="p-6 space-y-4">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                </Card>
              ))}
            </div>
          ) : filteredStories && filteredStories.length > 0 ? (
            <>
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Showing {filteredStories.length} {filteredStories.length === 1 ? "story" : "stories"}
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredStories.map((story) => (
                  <Link key={story.id} href={`/stories/${story.id}`} data-testid={`link-story-${story.id}`}>
                    <StoryCard story={story} />
                  </Link>
                ))}
              </div>
            </>
          ) : (
            <Card className="p-12 text-center mt-8">
              <BookOpen className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-heading text-xl font-bold mb-2">No stories found</h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your filters or check back later for new stories
              </p>
              <Button onClick={() => { setSelectedCategory("all"); setSelectedAgeGroup("all"); }} data-testid="button-clear-filters">
                Clear Filters
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
