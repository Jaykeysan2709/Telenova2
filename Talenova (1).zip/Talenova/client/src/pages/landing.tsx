import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Globe, Trophy, Sparkles, Star, Users, Heart, Play, ArrowRight, Languages, Theater, Map } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import heroBackground from "@assets/generated_images/magical_african_storytelling_campfire_scene.png";

export default function Landing() {
  const [showAuth, setShowAuth] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);
    
    try {
      await apiRequest('POST', '/api/auth/register', {
        email: formData.get('email'),
        password: formData.get('password'),
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
      window.location.href = '/';
    } catch (error: any) {
      toast({
        title: "Registration Failed",
        description: error.message || "Could not create account",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);
    
    try {
      await apiRequest('POST', '/api/auth/login', {
        email: formData.get('email'),
        password: formData.get('password'),
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
      window.location.href = '/';
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid email or password",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (showAuth) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center p-6 relative"
        style={{
          backgroundImage: `url(${heroBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
        
        <div className="w-full max-w-md relative z-10">
          <div className="text-center mb-8">
            <h1 className="font-heading text-5xl font-bold mb-3 text-white drop-shadow-lg" data-testid="text-landing-title">
              Tale-Nova
            </h1>
            <p className="text-white/90 text-lg italic">telling old african stories in a new way</p>
          </div>

          <Card className="backdrop-blur-md bg-card/95 shadow-2xl border-white/20">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 m-4 w-[calc(100%-2rem)]" data-testid="tabs-auth">
                <TabsTrigger value="login" data-testid="tab-login">Login</TabsTrigger>
                <TabsTrigger value="register" data-testid="tab-register">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="mt-0">
                <CardHeader className="pt-2">
                  <CardTitle>Welcome Back</CardTitle>
                  <CardDescription>Sign in to continue your adventure</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <Input 
                        id="login-email" 
                        name="email" 
                        type="email" 
                        placeholder="you@example.com" 
                        required 
                        data-testid="input-login-email"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="login-password">Password</Label>
                        <Link href="/forgot-password">
                          <Button 
                            type="button" 
                            variant="ghost" 
                            className="h-auto p-0 text-xs text-primary hover:text-primary/80 hover:bg-transparent"
                            data-testid="link-forgot-password"
                          >
                            Forgot password?
                          </Button>
                        </Link>
                      </div>
                      <Input 
                        id="login-password" 
                        name="password" 
                        type="password" 
                        required 
                        data-testid="input-login-password"
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading} data-testid="button-login-submit">
                      {isLoading ? "Logging in..." : "Start Your Journey"}
                    </Button>

                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
                      </div>
                    </div>

                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={() => window.location.href = '/api/auth/oauth/login'}
                      data-testid="button-oauth-login"
                    >
                      <Globe className="mr-2 h-4 w-4" />
                      Sign in with Social Login
                    </Button>
                  </form>
                </CardContent>
              </TabsContent>
              
              <TabsContent value="register" className="mt-0">
                <CardHeader className="pt-2">
                  <CardTitle>Join the Adventure</CardTitle>
                  <CardDescription>Create your account to explore African stories</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="register-firstName">First Name</Label>
                        <Input 
                          id="register-firstName" 
                          name="firstName" 
                          placeholder="First" 
                          data-testid="input-register-firstname"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-lastName">Last Name</Label>
                        <Input 
                          id="register-lastName" 
                          name="lastName" 
                          placeholder="Last" 
                          data-testid="input-register-lastname"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-email">Email</Label>
                      <Input 
                        id="register-email" 
                        name="email" 
                        type="email" 
                        placeholder="you@example.com" 
                        required 
                        data-testid="input-register-email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-password">Password</Label>
                      <Input 
                        id="register-password" 
                        name="password" 
                        type="password" 
                        required 
                        minLength={6}
                        data-testid="input-register-password"
                      />
                      <p className="text-xs text-muted-foreground">At least 6 characters</p>
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading} data-testid="button-register-submit">
                      {isLoading ? "Creating account..." : "Begin Your Journey"}
                    </Button>

                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
                      </div>
                    </div>

                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={() => window.location.href = '/api/auth/oauth/login'}
                      data-testid="button-oauth-register"
                    >
                      <Globe className="mr-2 h-4 w-4" />
                      Sign up with Social Login
                    </Button>
                  </form>
                </CardContent>
              </TabsContent>
            </Tabs>
          </Card>

          <div className="mt-6 text-center">
            <Button 
              variant="ghost" 
              onClick={() => setShowAuth(false)} 
              className="text-white/90 hover:text-white hover:bg-white/10"
              data-testid="button-back"
            >
              Back to home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Hero Section with Background Image */}
      <div 
        className="relative min-h-screen flex items-center justify-center"
        style={{
          backgroundImage: `url(${heroBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center bottom',
        }}
      >
        {/* Gradient overlay for readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/60" />
        
        {/* Magical floating fireflies */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Large glowing orbs */}
          <div className="absolute top-[15%] left-[10%] w-4 h-4 bg-yellow-300 rounded-full animate-pulse opacity-80 blur-[2px] shadow-lg shadow-yellow-400/50" style={{ animationDuration: '2s' }} />
          <div className="absolute top-[25%] right-[15%] w-3 h-3 bg-amber-400 rounded-full animate-pulse opacity-70 blur-[1px] shadow-lg shadow-amber-400/50" style={{ animationDuration: '2.5s', animationDelay: '0.5s' }} />
          <div className="absolute top-[40%] left-[20%] w-2 h-2 bg-orange-300 rounded-full animate-pulse opacity-60 blur-[1px]" style={{ animationDuration: '3s', animationDelay: '1s' }} />
          <div className="absolute top-[35%] right-[25%] w-3 h-3 bg-yellow-400 rounded-full animate-pulse opacity-75 blur-[1px] shadow-md shadow-yellow-400/40" style={{ animationDuration: '2.2s', animationDelay: '0.3s' }} />
          <div className="absolute bottom-[35%] left-[30%] w-4 h-4 bg-amber-300 rounded-full animate-pulse opacity-65 blur-[2px] shadow-lg shadow-amber-300/50" style={{ animationDuration: '2.8s', animationDelay: '1.5s' }} />
          <div className="absolute bottom-[45%] right-[10%] w-2 h-2 bg-yellow-200 rounded-full animate-pulse opacity-80" style={{ animationDuration: '1.8s', animationDelay: '0.7s' }} />
          <div className="absolute top-[60%] left-[8%] w-3 h-3 bg-orange-400 rounded-full animate-pulse opacity-55 blur-[1px]" style={{ animationDuration: '3.2s', animationDelay: '2s' }} />
          <div className="absolute top-[20%] left-[45%] w-2 h-2 bg-yellow-300 rounded-full animate-pulse opacity-70" style={{ animationDuration: '2.4s', animationDelay: '1.2s' }} />
          <div className="absolute bottom-[25%] right-[35%] w-3 h-3 bg-amber-400 rounded-full animate-pulse opacity-60 blur-[1px] shadow-md shadow-amber-400/30" style={{ animationDuration: '2.6s', animationDelay: '0.8s' }} />
          <div className="absolute top-[50%] right-[40%] w-2 h-2 bg-yellow-400 rounded-full animate-pulse opacity-75" style={{ animationDuration: '2s', animationDelay: '1.8s' }} />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-6 py-20 text-center">
          <Badge className="mb-6 bg-gradient-to-r from-amber-500/30 to-orange-500/30 text-white border-amber-400/40 backdrop-blur-md px-5 py-2.5 text-sm shadow-lg shadow-amber-500/20">
            <Star className="w-4 h-4 mr-2 fill-yellow-400 text-yellow-400 animate-pulse" />
            For children ages 4-13
          </Badge>
          
          <h1 
            className="font-heading text-6xl md:text-8xl lg:text-9xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-b from-white via-white to-amber-200/90" 
            style={{ 
              textShadow: '0 0 60px rgba(251, 191, 36, 0.3), 0 4px 30px rgba(0,0,0,0.5)',
              WebkitTextStroke: '1px rgba(255,255,255,0.1)'
            }}
            data-testid="text-hero-title"
          >
            Tale-Nova
          </h1>
          
          <p 
            className="text-2xl md:text-3xl lg:text-4xl text-amber-100/95 mb-4 font-light italic" 
            style={{ textShadow: '0 2px 20px rgba(0,0,0,0.5)' }}
            data-testid="text-hero-subtitle"
          >
            telling old african stories in a new way
          </p>
          
          <p className="text-lg md:text-xl text-white/85 mb-12 max-w-2xl mx-auto leading-relaxed" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.4)' }}>
            Connect children with rich African folklore, languages, and cultural wisdom 
            through magical, immersive storytelling adventures.
          </p>
          
          <div className="flex flex-wrap gap-5 justify-center">
            <Button 
              size="lg" 
              onClick={() => setShowAuth(true)}
              className="text-lg px-10 py-7 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-2xl shadow-orange-500/40 border border-amber-400/30 transition-all duration-300 hover:scale-105 hover:shadow-orange-500/50"
              data-testid="button-get-started"
            >
              <Play className="mr-2 h-5 w-5" />
              Start Your Adventure
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => {
                document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-lg px-8 py-7 bg-white/10 border-white/40 text-white hover:bg-white/20 backdrop-blur-md shadow-xl transition-all duration-300 hover:scale-105"
              data-testid="button-learn-more"
            >
              Explore Features
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>

          {/* Stats with glass effect */}
          <div className="mt-20 grid grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="text-center p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 shadow-xl">
              <p className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-amber-200">50+</p>
              <p className="text-white/80 text-sm md:text-base mt-1">African Stories</p>
            </div>
            <div className="text-center p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 shadow-xl">
              <p className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-amber-200">5</p>
              <p className="text-white/80 text-sm md:text-base mt-1">Languages</p>
            </div>
            <div className="text-center p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 shadow-xl">
              <p className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-amber-200">40+</p>
              <p className="text-white/80 text-sm md:text-base mt-1">Proverbs</p>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-10 h-14 rounded-full border-2 border-white/60 flex items-start justify-center pt-2 backdrop-blur-sm bg-white/5">
            <div className="w-1.5 h-3 bg-gradient-to-b from-white to-amber-300 rounded-full animate-pulse" />
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="features" className="bg-gradient-to-b from-amber-50 via-orange-50 to-yellow-50 py-24 relative overflow-hidden">
        {/* Fun pattern overlay */}
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #fbbf24 1px, transparent 0)', backgroundSize: '50px 50px' }} />
        
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-orange-100 text-orange-700 border-orange-300">Explore Our World</Badge>
            <h2 className="font-heading text-4xl md:text-5xl font-bold mb-4 text-amber-900" data-testid="text-features-title">
              A World of African Wonder Awaits
            </h2>
            <p className="text-xl text-amber-700 max-w-2xl mx-auto">
              Discover stories, languages, games, and cultural treasures from across the African continent.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="group p-8 bg-white/80 backdrop-blur-sm border-2 border-amber-200 hover:border-amber-400 transition-all duration-300 hover:shadow-xl hover:shadow-amber-200/50 rounded-3xl" data-testid="card-feature-stories">
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-amber-300/50">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-heading text-2xl font-bold mb-3 text-amber-900">Digital Story Library</h3>
              <p className="text-amber-700 leading-relaxed">
                Explore authentic folktales featuring beloved characters like Anansi the Spider, 
                the wise Tortoise, and the mysterious Mami Wata.
              </p>
            </Card>

            <Card className="group p-8 bg-white/80 backdrop-blur-sm border-2 border-orange-200 hover:border-orange-400 transition-all duration-300 hover:shadow-xl hover:shadow-orange-200/50 rounded-3xl" data-testid="card-feature-live-story">
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-orange-400 to-red-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-orange-300/50">
                <Theater className="h-8 w-8 text-white" />
              </div>
              <Badge className="mb-3 bg-orange-100 text-orange-600 border-orange-300">New</Badge>
              <h3 className="font-heading text-2xl font-bold mb-3 text-amber-900">"Live the Story" Gameplay</h3>
              <p className="text-amber-700 leading-relaxed">
                Step into African folktales as the main character! Make choices that shape your 
                adventure and discover multiple endings.
              </p>
            </Card>

            <Card className="group p-8 bg-white/80 backdrop-blur-sm border-2 border-yellow-200 hover:border-yellow-400 transition-all duration-300 hover:shadow-xl hover:shadow-yellow-200/50 rounded-3xl" data-testid="card-feature-languages">
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-yellow-300/50">
                <Languages className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-heading text-2xl font-bold mb-3 text-amber-900">Language Learning</h3>
              <p className="text-amber-700 leading-relaxed">
                Learn phrases in Yoruba, Swahili, Igbo, Zulu, and Hausa through 
                interactive flashcards and pronunciation guides.
              </p>
            </Card>

            <Card className="group p-8 bg-white/80 backdrop-blur-sm border-2 border-amber-200 hover:border-amber-400 transition-all duration-300 hover:shadow-xl hover:shadow-amber-200/50 rounded-3xl" data-testid="card-feature-games">
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-green-400 to-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-green-300/50">
                <Trophy className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-heading text-2xl font-bold mb-3 text-amber-900">Educational Games</h3>
              <p className="text-amber-700 leading-relaxed">
                Play fun trivia games, match proverbs with meanings, and test your knowledge 
                of African culture while earning badges.
              </p>
            </Card>

            <Card className="group p-8 bg-white/80 backdrop-blur-sm border-2 border-purple-200 hover:border-purple-400 transition-all duration-300 hover:shadow-xl hover:shadow-purple-200/50 rounded-3xl" data-testid="card-feature-ai">
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-purple-300/50">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-heading text-2xl font-bold mb-3 text-amber-900">AI Story Builder</h3>
              <p className="text-amber-700 leading-relaxed">
                Create your own unique African stories with our AI-powered story generator. 
                Choose characters, themes, and morals!
              </p>
            </Card>

            <Card className="group p-8 bg-white/80 backdrop-blur-sm border-2 border-blue-200 hover:border-blue-400 transition-all duration-300 hover:shadow-xl hover:shadow-blue-200/50 rounded-3xl" data-testid="card-feature-map">
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-blue-400 to-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-blue-300/50">
                <Map className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-heading text-2xl font-bold mb-3 text-amber-900">Cultural Map</h3>
              <p className="text-amber-700 leading-relaxed">
                Explore an interactive map of Africa to discover stories, languages, 
                and traditions from different regions.
              </p>
            </Card>
          </div>
        </div>
      </div>

      {/* Testimonial / Values Section */}
      <div className="bg-gradient-to-br from-yellow-50 via-amber-50 to-orange-50 py-24 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-amber-200 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-orange-200 rounded-full blur-3xl opacity-50" />
        
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <Badge className="mb-4 bg-amber-100 text-amber-700 border-amber-300">Why Tale-Nova?</Badge>
              <h2 className="font-heading text-4xl md:text-5xl font-bold mb-6 text-amber-900">
                Connecting Children to Their Heritage
              </h2>
              <p className="text-lg text-amber-700 mb-8 leading-relaxed">
                Tale-Nova bridges generations, bringing timeless African wisdom to children 
                growing up in a digital age. Through stories, games, and language learning, 
                we help children develop a strong sense of identity and pride in their roots.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-400 to-red-400 flex items-center justify-center shrink-0 shadow-lg shadow-pink-300/50">
                    <Heart className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-amber-800 font-medium">Age-appropriate content for children 4-13</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-indigo-400 flex items-center justify-center shrink-0 shadow-lg shadow-blue-300/50">
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-amber-800 font-medium">Designed for the African diaspora worldwide</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-emerald-400 flex items-center justify-center shrink-0 shadow-lg shadow-green-300/50">
                    <Globe className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-amber-800 font-medium">Stories from all regions of Africa</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <Card className="p-8 bg-white border-2 border-amber-200 shadow-2xl shadow-amber-200/30 rounded-3xl">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <blockquote className="text-xl font-medium mb-6 text-amber-800 italic">
                  "Tale-Nova has helped my children connect with their Nigerian heritage in 
                  such a fun and engaging way. They love the Anansi stories and can now 
                  greet family in Yoruba!"
                </blockquote>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-amber-300/50">
                    AM
                  </div>
                  <div>
                    <p className="font-semibold text-amber-900">Adaeze M.</p>
                    <p className="text-sm text-amber-600">Parent of 3, London</p>
                  </div>
                </div>
              </Card>
              <div className="absolute -z-10 -top-4 -right-4 w-full h-full rounded-3xl bg-gradient-to-br from-amber-200 to-orange-200" />
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative py-24 bg-gradient-to-br from-orange-100 via-amber-100 to-yellow-100 overflow-hidden">
        {/* Fun decorative shapes */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-amber-300/40 rounded-full blur-2xl" />
        <div className="absolute bottom-10 right-10 w-24 h-24 bg-orange-300/40 rounded-full blur-2xl" />
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-yellow-300/30 rounded-full blur-xl" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-heading text-4xl md:text-5xl font-bold mb-6 text-amber-900" data-testid="text-cta-title">
            Ready to Begin Your Journey?
          </h2>
          <p className="text-xl text-amber-700 mb-10 max-w-2xl mx-auto">
            Join Tale-Nova today and immerse yourself in the rich heritage of African storytelling. 
            The adventure awaits!
          </p>
          <Button 
            size="lg"
            onClick={() => setShowAuth(true)}
            className="text-lg px-12 py-7 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-2xl shadow-orange-300/50 border border-amber-400/30 transition-all duration-300 hover:scale-105 text-white"
            data-testid="button-sign-in"
          >
            <Sparkles className="mr-2 h-5 w-5" />
            Start Your Free Adventure
          </Button>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gradient-to-b from-amber-100 to-orange-100 border-t border-amber-200">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="text-center">
            <h3 className="font-heading text-2xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600">Tale-Nova</h3>
            <p className="text-amber-700 italic mb-6">telling old african stories in a new way</p>
            <p className="text-sm text-amber-600">
              Celebrating African culture through interactive storytelling and language learning.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
