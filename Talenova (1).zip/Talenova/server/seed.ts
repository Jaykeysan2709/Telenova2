import { db } from "./db";
import {
  stories,
  languagePhrases,
  proverbs,
  badges,
  type InsertStory,
  type InsertLanguagePhrase,
  type InsertProverb,
  type InsertBadge,
} from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  const seedStories: InsertStory[] = [
    {
      id: "1",
      title: "Anansi and the Box of Stories",
      content: `Long ago, all the stories in the world belonged to Nyame, the Sky God. Anansi the spider wanted these stories for all the creatures of the earth to enjoy.\n\nAnansi went to Nyame and asked, "What must I do to buy your stories?" Nyame laughed and said, "Many have tried, but all have failed. You must bring me three things: Onini the python, Osebo the leopard, and the Mmoboro hornets."\n\nAnansi was small but clever. First, he found a long bamboo pole and went to the python, saying, "My wife says you are not as long as this pole." The proud python stretched himself along the pole to prove he was longer, and Anansi quickly tied him up.\n\nNext, Anansi dug a pit and covered it with branches. When Osebo fell in, Anansi offered to help him out with his web, then captured him. Finally, Anansi filled a gourd with water and poured it over the hornets' nest, offering them shelter from the "rain" in an empty gourd, then trapped them inside.\n\nWhen Anansi brought all three to Nyame, the Sky God was amazed. He gave Anansi the golden box of stories, saying, "From now on, all stories shall be called Spider Stories." And that is why we tell Anansi tales to this day.`,
      region: "West Africa",
      country: "Ghana",
      language: "Akan",
      category: "folklore",
      ageGroup: "8-10",
      moral: "Wisdom and cleverness can overcome great challenges, even when you are small.",
      culturalContext: "Anansi is one of the most important figures in West African and Caribbean folklore. This tale explains why stories are often called 'Spider Stories' in Akan culture. Anansi represents the triumph of intelligence over strength, a valued trait in many African societies.",
      difficulty: 2,
      character: "Anansi the Spider",
    },
    {
      id: "2",
      title: "Why Tortoise Has a Cracked Shell",
      content: `During a great famine, the birds were invited to a feast in the sky. Tortoise was very hungry and wanted to go, but he had no wings. Using his clever words, he convinced the birds to each give him a feather so he could fly with them.\n\nBefore they left, Tortoise told the birds, "At feasts like this, it is customary to take a new name. I shall be called 'All of you.'" The birds thought this was a fine idea and each chose their own new name.\n\nWhen they arrived at the feast, the hosts asked, "Who is this food for?" Tortoise quickly replied, "For 'All of you,' of course!" Since that was his new name, Tortoise ate the best food while the birds received only scraps.\n\nThe birds were furious at being tricked. On the way home, they took back their feathers, leaving Tortoise stranded in the sky. Tortoise begged Parrot to tell his wife to bring out all the soft things from his house to cushion his fall.\n\nBut Parrot, still angry, told Tortoise's wife to bring out all the hard things instead. When Tortoise jumped, he crashed onto stones and hard objects, cracking his smooth shell into many pieces.\n\nAlthough his wife carefully glued the pieces back together, you can still see the cracks in Tortoise's shell to this day, a reminder of his greed.`,
      region: "West Africa",
      country: "Nigeria",
      language: "Igbo",
      category: "folklore",
      ageGroup: "8-10",
      moral: "Greed and trickery may bring short-term gains, but they often lead to lasting consequences.",
      culturalContext: "The tortoise is a central character in many Nigerian folktales, particularly among the Igbo people. Like Anansi, Tortoise is known for his cunning, but his stories often teach lessons about the dangers of being too clever or greedy. This tale explains a physical feature of the tortoise while teaching about humility and the consequences of deception.",
      difficulty: 2,
      character: "Tortoise",
    },
    {
      id: "3",
      title: "The Lion and the Rabbit",
      content: `In the great savanna, there lived a fierce lion who terrorized all the animals. Every day, he would hunt and kill many creatures for sport, not just for food. The animals called a meeting and decided to make a deal with the lion.\n\n"Great Lion," said the eldest elephant, "if you promise to stay in your den, we will send you one animal each day for your meal. This way, you won't need to hunt, and fewer of us will die."\n\nThe lion agreed, thinking this was easier than hunting. Each day, a different animal would go to the lion's den. When it was the rabbit's turn, she had a clever plan.\n\nThe rabbit arrived at the lion's den very late, when the lion was already angry and hungry. "Why are you late?" roared the lion. "And you are so small! You will barely make a snack!"\n\n"Forgive me, great Lion," said the rabbit. "I started coming early this morning, but on the way, I met another lion. He said he was the king of this savanna and tried to eat me. I told him I was meant for you, but he said you were nothing compared to him."\n\nThe lion was furious. "Show me this lion who dares to challenge me!"\n\nThe clever rabbit led the lion to a deep well. "He lives down there," she said. When the lion looked into the well, he saw his own reflection in the water.\n\n"Come up and fight me!" roared the lion. His reflection seemed to roar back. Enraged, the lion jumped into the well to fight his "rival," and he was never seen again.\n\nThe rabbit returned to the other animals with the good news, and they all lived in peace. The small rabbit had saved them all with her wit and courage.`,
      region: "East Africa",
      country: "Kenya",
      language: "Swahili",
      category: "fable",
      ageGroup: "4-7",
      moral: "Intelligence and cleverness are more powerful than size or strength.",
      culturalContext: "This East African fable is told across many regions and appears in various forms. It teaches children that problems can be solved through clever thinking rather than brute force. In many African cultures, the rabbit or hare is a symbol of wit and resourcefulness, using intelligence to overcome larger, stronger opponents.",
      difficulty: 1,
      character: "Rabbit",
    },
    {
      id: "4",
      title: "The Magic Drum of Oyo",
      content: `Long ago in the ancient kingdom of Oyo, there lived a poor farmer named Adekunle. One day, while working in his fields, he helped a strange old woman carrying heavy firewood. In gratitude, she gave him a small drum.\n\n"This is a magic drum," she said. "Whenever you are hungry, beat it once, and you will have food. But remember - you must never let a greedy person touch it, or the magic will turn against you."\n\nAdekunle thanked her and took the drum home. That evening, when his family was hungry, he beat the drum once. Immediately, a feast appeared before them - jollof rice, pounded yam, egusi soup, and sweet plantains. His family ate until they were full, and there was still food left over!\n\nWord of Adekunle's magic drum spread throughout the village. His family never went hungry, and he often shared his food with neighbors in need. The people loved and respected him.\n\nBut the Oba's advisor, a greedy man named Balogun, heard about the drum and wanted it for himself. One night, he snuck into Adekunle's house and stole the drum.\n\nThe next morning, Balogun beat the drum in his palace, expecting a feast. Instead, the drum began to beat itself! It beat louder and louder, and instead of food, wasps and bees poured out, chasing Balogun through the palace!\n\nBalogun ran to Adekunle's house and begged for forgiveness, returning the drum. Adekunle forgave him and taught him an important lesson: "Magic and blessings are meant to be used for good and shared with others, never for greed."`,
      region: "West Africa",
      country: "Nigeria",
      language: "Yoruba",
      category: "folklore",
      ageGroup: "8-10",
      moral: "Generosity and kindness are rewarded, while greed leads to suffering.",
      culturalContext: "This Yoruba tale from Nigeria emphasizes the cultural values of generosity and community sharing. The Oyo Empire was one of the most powerful West African kingdoms. In Yoruba culture, magic items in stories often come with conditions that test a person's character. The story also shows the importance of helping elders and strangers, as blessings often come from unexpected places.",
      difficulty: 2,
      character: "Adekunle the Farmer",
    },
    {
      id: "5",
      title: "How the Leopard Got His Spots",
      content: `In the beginning, the leopard had no spots at all. His coat was plain and golden like the sand. He lived in the savanna with his friend the zebra, who also had a plain brown coat.\n\nOne day, the Great Spirit called all the animals together. "The world is changing," said the Great Spirit. "Some of you live in the forest, some in the grasslands, some in the mountains. You must adapt to your homes so you can thrive."\n\nThe zebra chose to live in the grasslands where tall grasses grew in stripes of gold and shadow. "I will have stripes like the grass," said the zebra. The Great Spirit granted her wish, and beautiful black and white stripes appeared on her coat.\n\nThe leopard chose to live in the forest, where sunlight fell in patches through the leaves, creating spots of light and shadow on the ground. "I will have spots like the forest floor," said the leopard. The Great Spirit granted his wish, and beautiful dark spots appeared all over his golden coat.\n\nFrom that day on, the leopard could hide perfectly in the dappled forest shadows, and the zebra could blend into the striped grasslands. Both animals thanked the Great Spirit for their beautiful new coats.\n\nThis is why, when you see a leopard today, you will always see spots, and when you see a zebra, you will always see stripes. They carry the patterns of their chosen homes on their very skin.`,
      region: "Southern Africa",
      country: "South Africa",
      language: "Zulu",
      category: "legend",
      ageGroup: "4-7",
      moral: "We are shaped by where we come from and where we choose to live.",
      culturalContext: "This Zulu creation story explains natural phenomena while teaching children about adaptation and belonging. In many African cultures, creation stories help children understand the natural world around them. These tales emphasize the connection between animals and their environment, showing that everything in nature has a purpose and reason.",
      difficulty: 1,
      character: "Leopard",
    },
    {
      id: "6",
      title: "The Talking Skull",
      content: `A hunter was walking through the forest when he saw a skull lying on the ground. To his surprise, the skull spoke: "Talking brought me here."\n\nThe hunter was amazed and ran to tell the king about the talking skull. The king didn't believe him and said, "If you are lying, you will be punished. Take me to this skull."\n\nThe hunter led the king and his warriors to the skull. "Speak!" commanded the hunter. But the skull remained silent. The hunter begged and pleaded, but the skull said nothing.\n\nThe angry king ordered his warriors to punish the hunter for wasting his time and lying. After the king left, the skull finally spoke again: "I told you - talking brought me here. And now talking has brought you here too."\n\nThe hunter learned too late that some things are better left alone, and not everything needs to be shared with others.`,
      region: "West Africa",
      country: "Nigeria",
      language: "Yoruba",
      category: "folklore",
      ageGroup: "11-13",
      moral: "Think carefully before you speak, and know when silence is wiser than words.",
      culturalContext: "This cautionary Yoruba tale teaches the importance of discretion and thinking before speaking. In many African cultures, wisdom includes knowing when to speak and when to remain silent. The story also warns against seeking attention or trying to impress others without considering the consequences.",
      difficulty: 3,
      character: "The Hunter",
    },
    {
      id: "7",
      title: "Sundiata: The Lion King of Mali",
      content: `Long ago in the kingdom of Mali, a prince named Sundiata was born. A prophecy said he would become a great king, but he could not walk until he was seven years old. Other children mocked him, and some thought he would never rule.\n\nSundiata's mother never lost faith. She encouraged him every day, telling him stories of great kings and warriors. One day, Sundiata decided he would walk. He called for an iron rod to help him stand.\n\nWhen Sundiata pulled himself up using the iron rod, it bent under his strength! He took his first steps, and from that day forward, he grew stronger and stronger. He learned to hunt, to fight, and to lead.\n\nWhen an evil sorcerer king named Soumaoro conquered Mali, Sundiata gathered an army. He united many kingdoms and clans who had been divided. Together, they defeated Soumaoro and freed Mali.\n\nSundiata became the first emperor of the great Mali Empire. He was called the Lion King because of his courage and strength. Under his rule, Mali became one of the richest and most powerful empires in the world.\n\nSundiata's story teaches us that challenges in our early life do not determine our future. With determination, support, and courage, we can achieve greatness.`,
      region: "West Africa",
      country: "Mali",
      language: "Mandinka",
      category: "legend",
      ageGroup: "11-13",
      moral: "Perseverance and determination can overcome any obstacle, no matter how difficult your beginning.",
      culturalContext: "Sundiata Keita was a real historical figure who founded the Mali Empire in the 13th century. His epic is one of Africa's greatest stories, passed down through generations by griots (traditional storytellers). The Mali Empire became famous for its wealth, especially under Mansa Musa, and for the ancient city of Timbuktu, a center of learning and trade.",
      difficulty: 3,
      character: "Sundiata Keita",
    },
    {
      id: "8",
      title: "Why the Sun and Moon Live in the Sky",
      content: `Long ago, the Sun and the Moon lived on Earth and were married. They had a close friend named Water, who lived nearby with all his fish, waves, and creatures.\n\nOne day, Sun and Moon invited Water to visit their house. Water agreed but warned them: "My people are many. Are you sure your house is big enough?" Sun and Moon said yes, so Water began to flow in.\n\nWater came with the fish, the dolphins, the waves, and all his family. Soon the water was up to Sun and Moon's knees. "Is it still okay?" asked Water. "Yes, keep coming!" they replied.\n\nThe water rose to their waists, then to their shoulders. Water asked again, "Are you sure?" Sun and Moon, not wanting to be rude, said yes. The water kept rising with all its creatures - sharks, whales, and sea turtles.\n\nFinally, the water reached the ceiling! Sun and Moon had to climb onto the roof. Still the water rose, and they had to climb higher and higher into the sky.\n\nWater took over their house completely, filling the whole Earth - creating the oceans, rivers, and lakes. Sun and Moon had no choice but to stay in the sky, where they remain to this day.\n\nThat is why water covers so much of the Earth, and why the Sun and Moon live in the sky, watching over us from above.`,
      region: "West Africa",
      country: "Nigeria",
      language: "Efik-Ibibio",
      category: "mythology",
      ageGroup: "4-7",
      moral: "Be honest about your limits, and don't agree to things just to be polite.",
      culturalContext: "This creation myth from the Efik-Ibibio people of Nigeria explains natural phenomena in a way that teaches practical wisdom. The story shows the importance of setting boundaries and being honest, even with friends. Such tales help children understand both the world around them and social relationships.",
      difficulty: 1,
      character: "Sun and Moon",
    },
    {
      id: "9",
      title: "The Clever Hare and the Crocodile",
      content: `Hare wanted to cross the river, but he knew that Crocodile lived there and loved to eat small animals. Hare was clever, so he made a plan.\n\nHare stood at the river's edge and called out, "Crocodile, the King wants to count all the crocodiles in the river! He wants to know if there are more crocodiles or more fish."\n\nCrocodile was proud and called all his family and friends. "Line up across the river so the King's messenger can count us!" he commanded.\n\nThe crocodiles lined up in a perfect row from one side of the river to the other. Hare began to hop from one crocodile's back to the next, counting: "One, two, three, four..."\n\nWhen Hare reached the other side, he jumped onto the bank and laughed. "Thank you for the bridge, foolish crocodiles! There is no King's count - I just needed to cross the river!"\n\nThe crocodiles were angry at being tricked, but Hare was already safely on the other side, hopping away through the grass. From that day on, crocodiles learned to be more suspicious of clever animals asking for favors.`,
      region: "East Africa",
      country: "Tanzania",
      language: "Swahili",
      category: "fable",
      ageGroup: "4-7",
      moral: "Quick thinking and creativity can help you solve difficult problems.",
      culturalContext: "The hare (or rabbit) is a clever trickster character in many East African stories, similar to Anansi in West Africa. These tales teach children that intelligence and wit are valuable tools for overcoming challenges. The stories also remind listeners to think critically and not believe everything they're told.",
      difficulty: 1,
      character: "Hare",
    },
    {
      id: "10",
      title: "Anansi Goes to the Feast",
      content: `Anansi the spider heard about two feasts happening at the same time - one upriver and one downriver. Being greedy, he wanted to attend both and eat twice as much food.\n\nAnansi tied one rope around his waist, with one end going upriver to his friend Rabbit's feast, and the other end going downriver to his friend Turtle's feast. He told each friend, "When your feast is ready, pull the rope and I will come."\n\nAnansi waited by the river, ready to go to whichever feast started first. But both friends began their feasts at exactly the same time! They both pulled their ropes at once.\n\nPoor Anansi was pulled in both directions at the same time! The ropes squeezed his waist tighter and tighter. He tried to call for help, but the water was too loud and no one could hear him.\n\nAnansi finally managed to untie the ropes, but it was too late - both feasts had ended. He had missed both meals! And his waist remained tiny and squeezed from being pulled so hard.\n\nThat is why spiders today have such thin waists - it's a reminder of Anansi's greed and his attempt to be in two places at once.`,
      region: "West Africa",
      country: "Ghana",
      language: "Akan",
      category: "folklore",
      ageGroup: "8-10",
      moral: "Greed can leave you with nothing. It's better to choose one good thing than to try to have everything.",
      culturalContext: "This is another popular Anansi tale that explains a physical characteristic of spiders. Anansi stories often involve the spider getting into trouble because of greed or trying to be too clever. These tales teach children about the consequences of greed and the importance of making choices.",
      difficulty: 2,
      character: "Anansi the Spider",
    },
    {
      id: "11",
      title: "The Rainbow Serpent",
      content: `In the Dreamtime, before the world had its current shape, there lived a great Rainbow Serpent deep beneath the earth. The world was flat and empty - no mountains, no rivers, no trees.\n\nOne day, the Rainbow Serpent woke from her long sleep and pushed her way to the surface. As she traveled across the land, her massive body carved out deep valleys and riverbeds wherever she went.\n\nThe Rainbow Serpent called forth the rain from the sky. The rain fell and filled the valleys she had made, creating the first rivers and lakes. Plants began to grow along the water's edge, and the land turned green and beautiful.\n\nShe created laws for all living things: respect the water, respect each other, and respect the land. Those who followed her laws were rewarded with water and abundance. Those who broke her laws and were cruel or greedy faced her anger.\n\nWhen the Rainbow Serpent was pleased, she would appear in the sky after the rain as a beautiful rainbow, reminding everyone of her blessings and her laws. The people knew that when they saw the rainbow, the Rainbow Serpent was watching over them.\n\nTo this day, when we see a rainbow after the rain, we remember the Rainbow Serpent and the laws she created to help all living things live together in harmony.`,
      region: "Southern Africa",
      country: "Zimbabwe",
      language: "Shona",
      category: "mythology",
      ageGroup: "8-10",
      moral: "We must respect nature and follow rules that help everyone live in harmony.",
      culturalContext: "The Rainbow Serpent is a powerful creation figure in many African cultures. This version comes from Zimbabwe's Shona people, but similar serpent creator stories exist across the continent. These tales teach respect for water as a source of life and emphasize the importance of natural laws and balance in the environment.",
      difficulty: 2,
      character: "Rainbow Serpent",
    },
    {
      id: "12",
      title: "The Gift of Fire",
      content: `Long ago, humans lived in darkness and cold because they did not have fire. All the fire in the world belonged to Thunder, who kept it in the sky and refused to share it.\n\nThe animals felt sorry for the humans and held a meeting. "We must help them," said Elephant. "But who is brave enough to steal fire from Thunder?"\n\nMany animals were afraid, but finally, small Mouse spoke up. "I will do it. I am small and quick. Thunder won't notice me."\n\nMouse climbed the tallest mountain and waited for a storm. When Thunder threw lightning to the earth, Mouse ran faster than she had ever run before. She caught a spark of fire in her mouth before it hit the ground.\n\nMouse ran down the mountain with the fire, but Thunder saw her and was furious! He threw lightning bolts to stop her, but Mouse was too quick. The heat from the fire she carried scorched her coat, turning it from white to brown.\n\nMouse brought the fire to the humans, who were grateful beyond words. They learned to keep the fire burning and to use it for warmth, cooking, and light. They shared it with all the villages, and humans were never cold or hungry again.\n\nThough Mouse's coat was forever changed from white to brown from carrying the hot fire, she was honored by all humans as the bravest of animals. And Thunder learned that some gifts are meant to be shared.`,
      region: "East Africa",
      country: "Uganda",
      language: "Luganda",
      category: "legend",
      ageGroup: "8-10",
      moral: "True courage means helping others even when you're small, and generosity brings more joy than hoarding.",
      culturalContext: "Fire origin stories are common across Africa, teaching about the importance of fire in human civilization. This Ugandan tale emphasizes that courage comes in all sizes and that the smallest among us can be heroes. It also teaches that knowledge and resources should be shared for the good of all.",
      difficulty: 2,
      character: "Mouse",
    },
    {
      id: "13",
      title: "The Wise Daughter",
      content: `A poor farmer had a daughter known throughout the land for her wisdom. One day, the farmer found a golden mortar (a bowl for grinding grain) in his field. He decided to give it to the king as a gift.\n\nHis daughter warned him: "Father, don't give just the mortar. The king will ask for the pestle (the grinding stick) too, and you don't have it. He'll think you're hiding it."\n\nBut the farmer didn't listen. When he presented the mortar to the king, the king demanded to know where the pestle was. The king threw the farmer in prison for "stealing" the pestle.\n\nThe daughter went to the king and asked for her father's release. The king was impressed by her confidence and gave her a challenge: "If you can come to me not walking and not riding, not dressed and not naked, not with a gift and not without a gift, I will free your father."\n\nThe clever daughter wrapped herself in a fishing net (not dressed, not naked), rode a goat with one foot on the ground (not walking, not riding), and brought a bird that flew away when she arrived (not with a gift, not without a gift).\n\nThe king was amazed by her wisdom. He freed her father and asked her to become his chief advisor. She agreed, and her wise counsel helped the kingdom prosper for many years.\n\nThe king learned that wisdom can be found in unexpected places, and that listening to wise advice - whether from men or women, rich or poor - makes a good ruler great.`,
      region: "West Africa",
      country: "Senegal",
      language: "Wolof",
      category: "folklore",
      ageGroup: "11-13",
      moral: "Wisdom and intelligence are more valuable than wealth or status, and everyone's counsel deserves to be heard.",
      culturalContext: "This Wolof tale challenges traditional gender roles and emphasizes that wisdom is not limited by age, gender, or social class. In many African societies, riddles and clever problem-solving are highly valued, and stories like this teach children to think creatively and value intelligence over material wealth.",
      difficulty: 3,
      character: "The Wise Daughter",
    },
    {
      id: "14",
      title: "The Greedy Dog",
      content: `A dog found a juicy bone and decided to take it home to eat in peace. To get home, he had to cross a bridge over a stream.\n\nAs the dog walked across the bridge, he looked down into the water. There he saw another dog with a bone that looked even bigger and juicier than his own!\n\nThe greedy dog didn't realize he was looking at his own reflection. He wanted both bones for himself. So he opened his mouth to bark and scare the other dog away.\n\nBut when he opened his mouth, his bone fell into the water with a splash! It sank to the bottom of the stream and was lost forever.\n\nThe dog stood on the bridge with nothing, realizing too late that the "other dog" was just his reflection. His greed had cost him the good bone he already had.\n\nSadly, the dog went home with an empty stomach, having learned an important lesson about being grateful for what you have.`,
      region: "East Africa",
      country: "Ethiopia",
      language: "Amharic",
      category: "fable",
      ageGroup: "4-7",
      moral: "Be grateful for what you have instead of being greedy for more, or you might lose everything.",
      culturalContext: "This Ethiopian fable teaches children about contentment and the dangers of greed. Similar versions of this story exist in many cultures, but the African versions often emphasize community values and sharing. The story uses simple imagery that young children can easily understand and remember.",
      difficulty: 1,
      character: "Dog",
    },
    {
      id: "15",
      title: "Mami Wata: The Water Spirit",
      content: `A young fisherman named Kwame went out to fish every day but caught very little. His family was hungry, and he was growing desperate.\n\nOne evening, as the sun set over the ocean, Kwame saw a beautiful woman sitting on the rocks. She had long flowing hair and wore jewelry that sparkled like water in moonlight. This was Mami Wata, the powerful water spirit.\n\n"Why do you look so sad?" asked Mami Wata. Kwame explained his troubles. Mami Wata smiled and said, "I will help you, but you must promise three things: fish only what you need, always throw back the small fish so they can grow, and share your catch with those who have none."\n\nKwame promised, and Mami Wata gave him a special net woven with silver thread. "This net will bring you fish, but remember your promise," she warned.\n\nFrom that day on, Kwame caught plenty of fish. He kept his promise - he took only what his family needed, released young fish back to the water, and shared with his neighbors. His village never went hungry.\n\nOne day, another fisherman saw Kwame's success and stole the magic net. This greedy man tried to catch every fish in the ocean. But Mami Wata saw his greed. She called up a great wave that took back her net and taught the greedy fisherman a lesson.\n\nKwame continued to fish with regular nets, but because he had honored his promise and respected the ocean, Mami Wata always ensured his nets were full. The village remembered: the sea provides for those who respect it and share its gifts.`,
      region: "West Africa",
      country: "Ghana",
      language: "Fante",
      category: "mythology",
      ageGroup: "11-13",
      moral: "Respect nature's gifts, take only what you need, and share with others in your community.",
      culturalContext: "Mami Wata (Mother Water) is one of the most important water spirits in West and Central African traditions. She represents the power and mystery of water bodies and teaches respect for nature. Stories of Mami Wata often emphasize sustainable living, respect for the environment, and the importance of keeping promises.",
      difficulty: 3,
      character: "Mami Wata",
    },
  ];

  const seedPhrases: InsertLanguagePhrase[] = [
    // Yoruba - Greetings
    { id: "1", language: "Yoruba", phrase: "Ẹ káàárọ̀", translation: "Good morning", pronunciation: "eh kah-ah-roh", category: "greetings" },
    { id: "2", language: "Yoruba", phrase: "Ẹ kú àṣálẹ́", translation: "Good evening", pronunciation: "eh koo ah-shah-leh", category: "greetings" },
    { id: "3", language: "Yoruba", phrase: "Báwo ni?", translation: "How are you?", pronunciation: "bah-woh nee", category: "greetings" },
    { id: "101", language: "Yoruba", phrase: "Ọ dàárọ̀", translation: "Good afternoon", pronunciation: "oh dah-ah-roh", category: "greetings" },
    { id: "102", language: "Yoruba", phrase: "Ó dàbọ̀", translation: "Goodbye", pronunciation: "oh dah-boh", category: "greetings" },
    
    // Yoruba - Numbers
    { id: "4", language: "Yoruba", phrase: "Ọ̀kan", translation: "One", pronunciation: "oh-kahn", category: "numbers" },
    { id: "5", language: "Yoruba", phrase: "Méjì", translation: "Two", pronunciation: "meh-jee", category: "numbers" },
    { id: "103", language: "Yoruba", phrase: "Mẹ́ta", translation: "Three", pronunciation: "meh-tah", category: "numbers" },
    { id: "104", language: "Yoruba", phrase: "Mẹ́rin", translation: "Four", pronunciation: "meh-reen", category: "numbers" },
    { id: "105", language: "Yoruba", phrase: "Màrún", translation: "Five", pronunciation: "mah-roon", category: "numbers" },
    
    // Yoruba - Family
    { id: "106", language: "Yoruba", phrase: "Bàbá", translation: "Father", pronunciation: "bah-bah", category: "family" },
    { id: "107", language: "Yoruba", phrase: "Ìyá", translation: "Mother", pronunciation: "ee-yah", category: "family" },
    { id: "108", language: "Yoruba", phrase: "Ọmọ", translation: "Child", pronunciation: "oh-moh", category: "family" },
    { id: "109", language: "Yoruba", phrase: "Ará ilé", translation: "Family", pronunciation: "ah-rah ee-leh", category: "family" },
    
    // Yoruba - Colors
    { id: "110", language: "Yoruba", phrase: "Funfun", translation: "White", pronunciation: "foon-foon", category: "colors" },
    { id: "111", language: "Yoruba", phrase: "Dúdú", translation: "Black", pronunciation: "doo-doo", category: "colors" },
    { id: "112", language: "Yoruba", phrase: "Pupa", translation: "Red", pronunciation: "poo-pah", category: "colors" },
    
    // Yoruba - Animals
    { id: "113", language: "Yoruba", phrase: "Ajá", translation: "Dog", pronunciation: "ah-jah", category: "animals" },
    { id: "114", language: "Yoruba", phrase: "Ológbò", translation: "Cat", pronunciation: "oh-log-boh", category: "animals" },
    { id: "115", language: "Yoruba", phrase: "Ẹyẹ", translation: "Bird", pronunciation: "eh-yeh", category: "animals" },
    
    // Swahili - Greetings
    { id: "6", language: "Swahili", phrase: "Habari", translation: "Hello/How are you", pronunciation: "hah-bah-ree", category: "greetings" },
    { id: "7", language: "Swahili", phrase: "Asante", translation: "Thank you", pronunciation: "ah-sahn-teh", category: "greetings" },
    { id: "8", language: "Swahili", phrase: "Karibu", translation: "Welcome", pronunciation: "kah-ree-boo", category: "greetings" },
    { id: "116", language: "Swahili", phrase: "Kwaheri", translation: "Goodbye", pronunciation: "kwah-heh-ree", category: "greetings" },
    { id: "117", language: "Swahili", phrase: "Tafadhali", translation: "Please", pronunciation: "tah-fahd-hah-lee", category: "greetings" },
    
    // Swahili - Numbers
    { id: "9", language: "Swahili", phrase: "Moja", translation: "One", pronunciation: "moh-jah", category: "numbers" },
    { id: "10", language: "Swahili", phrase: "Mbili", translation: "Two", pronunciation: "mbee-lee", category: "numbers" },
    { id: "118", language: "Swahili", phrase: "Tatu", translation: "Three", pronunciation: "tah-too", category: "numbers" },
    { id: "119", language: "Swahili", phrase: "Nne", translation: "Four", pronunciation: "n-neh", category: "numbers" },
    { id: "120", language: "Swahili", phrase: "Tano", translation: "Five", pronunciation: "tah-noh", category: "numbers" },
    
    // Swahili - Family
    { id: "121", language: "Swahili", phrase: "Baba", translation: "Father", pronunciation: "bah-bah", category: "family" },
    { id: "122", language: "Swahili", phrase: "Mama", translation: "Mother", pronunciation: "mah-mah", category: "family" },
    { id: "123", language: "Swahili", phrase: "Mtoto", translation: "Child", pronunciation: "m-toh-toh", category: "family" },
    { id: "124", language: "Swahili", phrase: "Familia", translation: "Family", pronunciation: "fah-mee-lee-ah", category: "family" },
    
    // Swahili - Colors
    { id: "125", language: "Swahili", phrase: "Nyeupe", translation: "White", pronunciation: "nyeh-oo-peh", category: "colors" },
    { id: "126", language: "Swahili", phrase: "Nyeusi", translation: "Black", pronunciation: "nyeh-oo-see", category: "colors" },
    { id: "127", language: "Swahili", phrase: "Nyekundu", translation: "Red", pronunciation: "nyeh-koon-doo", category: "colors" },
    
    // Swahili - Animals
    { id: "128", language: "Swahili", phrase: "Mbwa", translation: "Dog", pronunciation: "m-bwah", category: "animals" },
    { id: "129", language: "Swahili", phrase: "Paka", translation: "Cat", pronunciation: "pah-kah", category: "animals" },
    { id: "130", language: "Swahili", phrase: "Ndege", translation: "Bird", pronunciation: "n-deh-geh", category: "animals" },
    { id: "131", language: "Swahili", phrase: "Simba", translation: "Lion", pronunciation: "seem-bah", category: "animals" },
    
    // Igbo - Greetings
    { id: "11", language: "Igbo", phrase: "Nnọọ", translation: "Welcome", pronunciation: "n-noh-oh", category: "greetings" },
    { id: "12", language: "Igbo", phrase: "Kedu", translation: "How are you?", pronunciation: "keh-doo", category: "greetings" },
    { id: "13", language: "Igbo", phrase: "Daalụ", translation: "Thank you", pronunciation: "dah-loo", category: "greetings" },
    { id: "132", language: "Igbo", phrase: "Ka ọ dị", translation: "Goodbye", pronunciation: "kah oh dee", category: "greetings" },
    { id: "133", language: "Igbo", phrase: "Biko", translation: "Please", pronunciation: "bee-koh", category: "greetings" },
    
    // Igbo - Numbers
    { id: "134", language: "Igbo", phrase: "Otu", translation: "One", pronunciation: "oh-too", category: "numbers" },
    { id: "135", language: "Igbo", phrase: "Abụọ", translation: "Two", pronunciation: "ah-boo-oh", category: "numbers" },
    { id: "136", language: "Igbo", phrase: "Atọ", translation: "Three", pronunciation: "ah-toh", category: "numbers" },
    { id: "137", language: "Igbo", phrase: "Anọ", translation: "Four", pronunciation: "ah-noh", category: "numbers" },
    { id: "138", language: "Igbo", phrase: "Ise", translation: "Five", pronunciation: "ee-seh", category: "numbers" },
    
    // Igbo - Family
    { id: "139", language: "Igbo", phrase: "Nna", translation: "Father", pronunciation: "n-nah", category: "family" },
    { id: "140", language: "Igbo", phrase: "Nne", translation: "Mother", pronunciation: "n-neh", category: "family" },
    { id: "141", language: "Igbo", phrase: "Nwa", translation: "Child", pronunciation: "n-wah", category: "family" },
    { id: "142", language: "Igbo", phrase: "Ezinụlọ", translation: "Family", pronunciation: "eh-zee-noo-loh", category: "family" },
    
    // Igbo - Colors
    { id: "143", language: "Igbo", phrase: "Ọcha", translation: "White", pronunciation: "oh-chah", category: "colors" },
    { id: "144", language: "Igbo", phrase: "Ojii", translation: "Black", pronunciation: "oh-jee", category: "colors" },
    { id: "145", language: "Igbo", phrase: "Uhie", translation: "Red", pronunciation: "oo-hee-eh", category: "colors" },
    
    // Igbo - Animals
    { id: "146", language: "Igbo", phrase: "Nkịta", translation: "Dog", pronunciation: "n-kee-tah", category: "animals" },
    { id: "147", language: "Igbo", phrase: "Nwamba", translation: "Cat", pronunciation: "n-wahm-bah", category: "animals" },
    { id: "148", language: "Igbo", phrase: "Nnụnụ", translation: "Bird", pronunciation: "n-noo-noo", category: "animals" },
    
    // Zulu - Greetings
    { id: "14", language: "Zulu", phrase: "Sawubona", translation: "Hello (to one)", pronunciation: "sah-woo-boh-nah", category: "greetings" },
    { id: "15", language: "Zulu", phrase: "Ngiyabonga", translation: "Thank you", pronunciation: "ngee-yah-bohn-gah", category: "greetings" },
    { id: "149", language: "Zulu", phrase: "Sanibonani", translation: "Hello (to many)", pronunciation: "sah-nee-boh-nah-nee", category: "greetings" },
    { id: "150", language: "Zulu", phrase: "Hamba kahle", translation: "Goodbye", pronunciation: "hahm-bah kah-hleh", category: "greetings" },
    { id: "151", language: "Zulu", phrase: "Ngicela", translation: "Please", pronunciation: "ngee-cheh-lah", category: "greetings" },
    
    // Zulu - Numbers
    { id: "152", language: "Zulu", phrase: "Kunye", translation: "One", pronunciation: "koo-nyeh", category: "numbers" },
    { id: "153", language: "Zulu", phrase: "Kubili", translation: "Two", pronunciation: "koo-bee-lee", category: "numbers" },
    { id: "154", language: "Zulu", phrase: "Kuthathu", translation: "Three", pronunciation: "koo-tah-too", category: "numbers" },
    { id: "155", language: "Zulu", phrase: "Kune", translation: "Four", pronunciation: "koo-neh", category: "numbers" },
    { id: "156", language: "Zulu", phrase: "Kuhlanu", translation: "Five", pronunciation: "koo-hlah-noo", category: "numbers" },
    
    // Zulu - Family
    { id: "157", language: "Zulu", phrase: "Ubaba", translation: "Father", pronunciation: "oo-bah-bah", category: "family" },
    { id: "158", language: "Zulu", phrase: "Umama", translation: "Mother", pronunciation: "oo-mah-mah", category: "family" },
    { id: "159", language: "Zulu", phrase: "Ingane", translation: "Child", pronunciation: "een-gah-neh", category: "family" },
    { id: "160", language: "Zulu", phrase: "Umndeni", translation: "Family", pronunciation: "oom-n-deh-nee", category: "family" },
    
    // Zulu - Colors
    { id: "161", language: "Zulu", phrase: "Mhlophe", translation: "White", pronunciation: "m-hloh-pheh", category: "colors" },
    { id: "162", language: "Zulu", phrase: "Mnyama", translation: "Black", pronunciation: "m-nyah-mah", category: "colors" },
    { id: "163", language: "Zulu", phrase: "Bomvu", translation: "Red", pronunciation: "bohm-voo", category: "colors" },
    
    // Zulu - Animals
    { id: "164", language: "Zulu", phrase: "Inja", translation: "Dog", pronunciation: "een-jah", category: "animals" },
    { id: "165", language: "Zulu", phrase: "Ikati", translation: "Cat", pronunciation: "ee-kah-tee", category: "animals" },
    { id: "166", language: "Zulu", phrase: "Inyoni", translation: "Bird", pronunciation: "een-yoh-nee", category: "animals" },
    { id: "167", language: "Zulu", phrase: "Ibhubesi", translation: "Lion", pronunciation: "ee-bhoo-beh-see", category: "animals" },
    
    // Hausa - Greetings
    { id: "16", language: "Hausa", phrase: "Sannu", translation: "Hello", pronunciation: "sahn-noo", category: "greetings" },
    { id: "17", language: "Hausa", phrase: "Na gode", translation: "Thank you", pronunciation: "nah goh-deh", category: "greetings" },
    { id: "168", language: "Hausa", phrase: "Sai an jima", translation: "Goodbye", pronunciation: "sah-ee ahn jee-mah", category: "greetings" },
    { id: "169", language: "Hausa", phrase: "Don Allah", translation: "Please", pronunciation: "dohn ahl-lah", category: "greetings" },
    { id: "170", language: "Hausa", phrase: "Barka da safe", translation: "Good morning", pronunciation: "bahr-kah dah sah-feh", category: "greetings" },
    
    // Hausa - Numbers
    { id: "171", language: "Hausa", phrase: "Ɗaya", translation: "One", pronunciation: "dah-yah", category: "numbers" },
    { id: "172", language: "Hausa", phrase: "Biyu", translation: "Two", pronunciation: "bee-yoo", category: "numbers" },
    { id: "173", language: "Hausa", phrase: "Uku", translation: "Three", pronunciation: "oo-koo", category: "numbers" },
    { id: "174", language: "Hausa", phrase: "Huɗu", translation: "Four", pronunciation: "hoo-doo", category: "numbers" },
    { id: "175", language: "Hausa", phrase: "Biyar", translation: "Five", pronunciation: "bee-yahr", category: "numbers" },
    
    // Hausa - Family
    { id: "176", language: "Hausa", phrase: "Uba", translation: "Father", pronunciation: "oo-bah", category: "family" },
    { id: "177", language: "Hausa", phrase: "Uwa", translation: "Mother", pronunciation: "oo-wah", category: "family" },
    { id: "178", language: "Hausa", phrase: "Yaro", translation: "Child", pronunciation: "yah-roh", category: "family" },
    { id: "179", language: "Hausa", phrase: "Iyali", translation: "Family", pronunciation: "ee-yah-lee", category: "family" },
    
    // Hausa - Colors
    { id: "180", language: "Hausa", phrase: "Fari", translation: "White", pronunciation: "fah-ree", category: "colors" },
    { id: "181", language: "Hausa", phrase: "Baƙi", translation: "Black", pronunciation: "bah-kee", category: "colors" },
    { id: "182", language: "Hausa", phrase: "Ja", translation: "Red", pronunciation: "jah", category: "colors" },
    
    // Hausa - Animals
    { id: "183", language: "Hausa", phrase: "Kare", translation: "Dog", pronunciation: "kah-reh", category: "animals" },
    { id: "184", language: "Hausa", phrase: "Kyanwa", translation: "Cat", pronunciation: "kyahn-wah", category: "animals" },
    { id: "185", language: "Hausa", phrase: "Tsuntsu", translation: "Bird", pronunciation: "tsoon-tsoo", category: "animals" },
    { id: "186", language: "Hausa", phrase: "Zaki", translation: "Lion", pronunciation: "zah-kee", category: "animals" },
  ];

  const seedProverbs: InsertProverb[] = [
    {
      id: "1",
      proverb: "It takes a village to raise a child",
      meaning: "Children are raised by the entire community, not just their parents. Everyone has a role in nurturing and teaching the young.",
      culture: "African (widespread)",
      category: "community",
    },
    {
      id: "2",
      proverb: "When the mouse laughs at the cat, there is a hole nearby",
      meaning: "Only be confident in your safety when you have a way to escape danger.",
      culture: "Nigerian",
      category: "wisdom",
    },
    {
      id: "3",
      proverb: "Smooth seas do not make skillful sailors",
      meaning: "Challenges and difficulties help us grow stronger and more capable.",
      culture: "African",
      category: "perseverance",
    },
    {
      id: "4",
      proverb: "A tree cannot stand without roots",
      meaning: "We must know and respect where we come from to grow strong.",
      culture: "African",
      category: "heritage",
    },
    {
      id: "5",
      proverb: "The one who asks questions doesn't lose their way",
      meaning: "Don't be afraid to ask for help or seek knowledge when you need it.",
      culture: "African",
      category: "learning",
    },
    {
      id: "6",
      proverb: "If you want to go fast, go alone. If you want to go far, go together",
      meaning: "Individual effort gets quick results, but teamwork achieves lasting success.",
      culture: "African",
      category: "community",
    },
    {
      id: "7",
      proverb: "A bird will always use another bird's feathers to feather its own nest",
      meaning: "We learn from and build upon what others have done before us.",
      culture: "Akan (Ghana)",
      category: "learning",
    },
    {
      id: "8",
      proverb: "The rain beats the leopard's skin, but it does not wash out the spots",
      meaning: "Your true nature and character cannot be changed by external circumstances.",
      culture: "Ashanti (Ghana)",
      category: "character",
    },
    {
      id: "9",
      proverb: "When there is no enemy within, the enemies outside cannot hurt you",
      meaning: "Inner peace and self-confidence protect you from external challenges.",
      culture: "African",
      category: "wisdom",
    },
    {
      id: "10",
      proverb: "A united family eats from the same plate",
      meaning: "Families who share and work together stay strong and connected.",
      culture: "Baganda (Uganda)",
      category: "family",
    },
    {
      id: "11",
      proverb: "The lizard that jumped from the high Iroko tree to the ground said he would praise himself if no one else did",
      meaning: "If others don't appreciate your achievements, you should still take pride in them yourself.",
      culture: "Yoruba (Nigeria)",
      category: "confidence",
    },
    {
      id: "12",
      proverb: "A single bracelet does not jingle",
      meaning: "One person alone cannot accomplish great things; we need cooperation.",
      culture: "Congolese",
      category: "community",
    },
    {
      id: "13",
      proverb: "He who learns must also suffer",
      meaning: "Growth and learning often come through challenges and difficult experiences.",
      culture: "Ethiopian",
      category: "learning",
    },
    {
      id: "14",
      proverb: "Ears that do not listen to advice, accompany the head when it is chopped off",
      meaning: "Those who refuse wise counsel will face the consequences of their stubbornness.",
      culture: "African",
      category: "wisdom",
    },
    {
      id: "15",
      proverb: "A roaring lion kills no game",
      meaning: "Actions speak louder than words; boasting accomplishes nothing.",
      culture: "African",
      category: "action",
    },
    {
      id: "16",
      proverb: "The best time to plant a tree was 20 years ago. The second best time is now",
      meaning: "It's never too late to start something worthwhile; begin today.",
      culture: "African",
      category: "action",
    },
    {
      id: "17",
      proverb: "Wisdom is like a baobab tree; no one individual can embrace it",
      meaning: "Knowledge is vast and unlimited; we can never know everything alone.",
      culture: "Akan (Ghana)",
      category: "wisdom",
    },
    {
      id: "18",
      proverb: "Until the lion learns to write, every story will glorify the hunter",
      meaning: "Those in power control the narrative; everyone deserves to tell their own story.",
      culture: "African",
      category: "justice",
    },
    {
      id: "19",
      proverb: "A family is like a forest; when you are outside it is dense, but when you are inside you see that each tree has its place",
      meaning: "Understanding comes from being inside a situation, not judging from the outside.",
      culture: "Akan (Ghana)",
      category: "family",
    },
    {
      id: "20",
      proverb: "No matter how full the river, it still wants to grow",
      meaning: "There is always room for growth and improvement, no matter how successful you are.",
      culture: "African",
      category: "growth",
    },
    {
      id: "21",
      proverb: "The fool speaks, the wise man listens",
      meaning: "Wise people learn by listening more than they talk.",
      culture: "Ethiopian",
      category: "wisdom",
    },
    {
      id: "22",
      proverb: "Slander by the stream will be heard by the frogs",
      meaning: "Secrets and gossip will eventually be discovered; be careful what you say.",
      culture: "African",
      category: "honesty",
    },
    {
      id: "23",
      proverb: "A small house will hold a hundred friends",
      meaning: "True friendship is not about the size of your home but the warmth of your heart.",
      culture: "Swahili (East Africa)",
      category: "friendship",
    },
    {
      id: "24",
      proverb: "The elephant does not limp when walking on thorns",
      meaning: "Great people endure hardships with strength and grace.",
      culture: "African",
      category: "strength",
    },
    {
      id: "25",
      proverb: "When spider webs unite, they can tie up a lion",
      meaning: "Working together, even the weak can overcome the strong.",
      culture: "Ethiopian",
      category: "unity",
    },
    {
      id: "26",
      proverb: "A happy man marries the girl he loves; a happier man loves the girl he marries",
      meaning: "True happiness comes from choosing to love and appreciate what you have.",
      culture: "African",
      category: "love",
    },
    {
      id: "27",
      proverb: "The ruin of a nation begins in the homes of its people",
      meaning: "Strong families build strong communities and nations.",
      culture: "Ashanti (Ghana)",
      category: "family",
    },
    {
      id: "28",
      proverb: "Knowledge without wisdom is like water in the sand",
      meaning: "Information alone is useless if you don't have the wisdom to use it well.",
      culture: "African",
      category: "wisdom",
    },
    {
      id: "29",
      proverb: "The young bird does not crow until it hears the old ones",
      meaning: "Children learn by watching and listening to their elders.",
      culture: "Tswana (Botswana)",
      category: "learning",
    },
    {
      id: "30",
      proverb: "Even the Niger River must flow around an island",
      meaning: "Even the most powerful must sometimes yield and adapt to obstacles.",
      culture: "West African",
      category: "flexibility",
    },
    {
      id: "31",
      proverb: "The child of an elephant will not be a dwarf",
      meaning: "Children tend to follow in their parents' footsteps and inherit their traits.",
      culture: "Yoruba (Nigeria)",
      category: "heritage",
    },
    {
      id: "32",
      proverb: "Do not look where you fell, but where you slipped",
      meaning: "Learn from what caused your mistake, not just the mistake itself.",
      culture: "Liberian",
      category: "learning",
    },
    {
      id: "33",
      proverb: "The man who has bread to eat does not appreciate the severity of a famine",
      meaning: "Those who have plenty cannot fully understand the suffering of those who have nothing.",
      culture: "Yoruba (Nigeria)",
      category: "empathy",
    },
    {
      id: "34",
      proverb: "A debt may get mouldy, but it never decays",
      meaning: "Obligations and responsibilities don't disappear with time; they must be fulfilled.",
      culture: "Somali",
      category: "responsibility",
    },
    {
      id: "35",
      proverb: "Two men in a burning house must not stop to argue",
      meaning: "In times of crisis, work together instead of fighting about differences.",
      culture: "Ashanti (Ghana)",
      category: "cooperation",
    },
    {
      id: "36",
      proverb: "The eye crosses the river before the body",
      meaning: "Planning and foresight are essential before taking action.",
      culture: "Basotho (Lesotho)",
      category: "planning",
    },
    {
      id: "37",
      proverb: "Patience can cook a stone",
      meaning: "With enough patience and persistence, even the impossible becomes possible.",
      culture: "African",
      category: "perseverance",
    },
    {
      id: "38",
      proverb: "If you close your eyes to facts, you will learn through accidents",
      meaning: "Ignoring the truth will eventually lead to painful consequences.",
      culture: "African",
      category: "truth",
    },
    {
      id: "39",
      proverb: "The Earth is a beehive; we all enter by the same door but live in different cells",
      meaning: "We all share the same world, but each person's experience is unique.",
      culture: "African",
      category: "diversity",
    },
    {
      id: "40",
      proverb: "Where you will sit when you are old shows where you stood in youth",
      meaning: "Your actions and choices today determine your future circumstances.",
      culture: "Yoruba (Nigeria)",
      category: "foresight",
    },
  ];

  const seedBadges: InsertBadge[] = [
    // Reading Badges
    {
      id: "1",
      name: "First Steps",
      description: "Begin your journey by reading your very first African story",
      icon: "book-open",
      requirement: "Read 1 story",
    },
    {
      id: "2",
      name: "Story Explorer",
      description: "You're discovering the magic of African tales",
      icon: "compass",
      requirement: "Read 5 stories",
    },
    {
      id: "3",
      name: "Tale Enthusiast",
      description: "Your love for stories is growing strong",
      icon: "book",
      requirement: "Read 10 stories",
    },
    {
      id: "4",
      name: "Story Collector",
      description: "You've gathered a wonderful collection of tales",
      icon: "library",
      requirement: "Read 25 stories",
    },
    {
      id: "5",
      name: "Master Storyteller",
      description: "You're a true keeper of African wisdom and tales",
      icon: "crown",
      requirement: "Read 50 stories",
    },
    
    // Language Learning Badges
    {
      id: "6",
      name: "Word Explorer",
      description: "You've learned your first African words",
      icon: "message-circle",
      requirement: "Learn 5 phrases",
    },
    {
      id: "7",
      name: "Language Learner",
      description: "You're building your African language vocabulary",
      icon: "graduation-cap",
      requirement: "Learn 10 phrases",
    },
    {
      id: "8",
      name: "Polyglot Beginner",
      description: "You're learning words from multiple languages",
      icon: "languages",
      requirement: "Learn phrases from 3 different languages",
    },
    {
      id: "9",
      name: "Language Scholar",
      description: "Your language skills are impressive",
      icon: "book-open",
      requirement: "Learn 25 phrases",
    },
    {
      id: "10",
      name: "Multilingual Master",
      description: "You've mastered words from all five African languages",
      icon: "globe",
      requirement: "Learn phrases from all 5 languages",
    },
    
    // Game Badges
    {
      id: "11",
      name: "Game Starter",
      description: "You played your first educational game",
      icon: "gamepad-2",
      requirement: "Play 1 game",
    },
    {
      id: "12",
      name: "Quiz Apprentice",
      description: "You're getting good at the games",
      icon: "target",
      requirement: "Earn 100 game points",
    },
    {
      id: "13",
      name: "Quiz Master",
      description: "Your game skills are shining bright",
      icon: "trophy",
      requirement: "Earn 500 game points",
    },
    {
      id: "14",
      name: "Game Champion",
      description: "You're a true gaming champion",
      icon: "award",
      requirement: "Earn 1000 game points",
    },
    {
      id: "15",
      name: "Perfect Score",
      description: "You achieved a perfect score in a game",
      icon: "star",
      requirement: "Get 100% in any game",
    },
    
    // Story Creation Badges
    {
      id: "16",
      name: "Story Creator",
      description: "You created your first unique African story",
      icon: "sparkles",
      requirement: "Generate 1 story with AI",
    },
    {
      id: "17",
      name: "Creative Mind",
      description: "Your imagination is creating wonderful tales",
      icon: "wand",
      requirement: "Generate 5 stories with AI",
    },
    {
      id: "18",
      name: "Master Creator",
      description: "You're a prolific creator of African tales",
      icon: "scroll",
      requirement: "Generate 10 stories with AI",
    },
    
    // Regional Exploration Badges
    {
      id: "19",
      name: "West Africa Explorer",
      description: "You've discovered the rich tales of West Africa",
      icon: "map-pin",
      requirement: "Read 5 stories from West Africa",
    },
    {
      id: "20",
      name: "East Africa Wanderer",
      description: "You've explored the wisdom of East Africa",
      icon: "map-pin",
      requirement: "Read 5 stories from East Africa",
    },
    {
      id: "21",
      name: "Southern Africa Discoverer",
      description: "You've journeyed through Southern African tales",
      icon: "map-pin",
      requirement: "Read 5 stories from Southern Africa",
    },
    {
      id: "22",
      name: "Cultural Ambassador",
      description: "You've explored stories from multiple African regions",
      icon: "globe",
      requirement: "Read stories from 3 different regions",
    },
    {
      id: "23",
      name: "Pan-African Scholar",
      description: "You've embraced the diversity of all African regions",
      icon: "world",
      requirement: "Read stories from all regions",
    },
    
    // Streak Badges
    {
      id: "24",
      name: "Dedicated Learner",
      description: "You've kept a 3-day learning streak",
      icon: "flame",
      requirement: "Maintain a 3-day streak",
    },
    {
      id: "25",
      name: "Consistent Student",
      description: "You've maintained a week-long learning streak",
      icon: "calendar",
      requirement: "Maintain a 7-day streak",
    },
    {
      id: "26",
      name: "Unstoppable",
      description: "You've achieved an impressive 30-day streak",
      icon: "zap",
      requirement: "Maintain a 30-day streak",
    },
    
    // Proverb Badges
    {
      id: "27",
      name: "Wisdom Seeker",
      description: "You've discovered African proverbs and their meanings",
      icon: "lightbulb",
      requirement: "Learn 5 proverbs",
    },
    {
      id: "28",
      name: "Wise One",
      description: "You're collecting the wisdom of African ancestors",
      icon: "brain",
      requirement: "Learn 10 proverbs",
    },
    {
      id: "29",
      name: "Elder's Wisdom",
      description: "You've embraced the deep wisdom of African culture",
      icon: "sparkles",
      requirement: "Learn 25 proverbs",
    },
    
    // Special Achievement Badges
    {
      id: "30",
      name: "Early Riser",
      description: "You started learning before 8 AM",
      icon: "sunrise",
      requirement: "Log in before 8 AM",
    },
    {
      id: "31",
      name: "Night Owl",
      description: "You're learning under the stars",
      icon: "moon",
      requirement: "Log in after 8 PM",
    },
    {
      id: "32",
      name: "Weekend Warrior",
      description: "You dedicated your weekend to learning",
      icon: "calendar-check",
      requirement: "Learn on Saturday and Sunday",
    },
    {
      id: "33",
      name: "Character Expert",
      description: "You've met Anansi, Tortoise, and other legendary characters",
      icon: "users",
      requirement: "Read stories featuring 5 different characters",
    },
    {
      id: "34",
      name: "Age Group Explorer",
      description: "You've explored stories for different age levels",
      icon: "layers",
      requirement: "Read stories from 3 different age groups",
    },
    {
      id: "35",
      name: "Completionist",
      description: "You've achieved excellence across all areas",
      icon: "medal",
      requirement: "Earn 20 different badges",
    },
  ];

  try {
    console.log("Inserting stories...");
    await db.insert(stories).values(seedStories).onConflictDoNothing();
    
    console.log("Inserting language phrases...");
    await db.insert(languagePhrases).values(seedPhrases).onConflictDoNothing();
    
    console.log("Inserting proverbs...");
    await db.insert(proverbs).values(seedProverbs).onConflictDoNothing();
    
    console.log("Inserting badges...");
    await db.insert(badges).values(seedBadges).onConflictDoNothing();
    
    console.log("✅ Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

seed().then(() => process.exit(0)).catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
