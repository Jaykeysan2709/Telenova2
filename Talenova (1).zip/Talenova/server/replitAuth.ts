// OAuth Authentication using Replit Auth (OpenID Connect)
// Supports Google, GitHub, X (Twitter), Apple, and email/password
// Reference: javascript_log_in_with_replit integration
import * as client from "openid-client";
import { Strategy, type VerifyFunction } from "openid-client/passport";

import passport from "passport";
import type { Express, RequestHandler } from "express";
import memoize from "memoizee";
import { storage } from "./storage";

const getOidcConfig = memoize(
  async () => {
    return await client.discovery(
      new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc"),
      process.env.REPL_ID!
    );
  },
  { maxAge: 3600 * 1000 }
);

// Helper function - currently unused but kept for future token refresh scenarios
function updateUserSession(
  user: any,
  tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers
) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}

async function upsertUser(claims: any) {
  const user = await storage.upsertUser({
    oauthSub: claims["sub"],
    email: claims["email"],
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"],
  });
  return user;
}

export async function setupOAuth(app: Express) {
  const config = await getOidcConfig();

  const verify: VerifyFunction = async (
    tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers,
    verified: passport.AuthenticateCallback
  ) => {
    // Upsert the user in the database
    const dbUser = await upsertUser(tokens.claims());
    
    // Pass only the database user to Passport (tokens will be stored separately in session)
    // The verified callback signature expects (error, user, info)
    // We'll attach tokens to req.session in the callback route handler
    verified(null, dbUser, { 
      tokens: {
        claims: tokens.claims(),
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        expires_at: tokens.claims()?.exp,
      }
    });
  };

  // Keep track of registered strategies
  const registeredStrategies = new Set<string>();

  // Helper function to ensure strategy exists for a domain
  const ensureStrategy = (domain: string) => {
    const strategyName = `replitauth:${domain}`;
    if (!registeredStrategies.has(strategyName)) {
      const strategy = new Strategy(
        {
          name: strategyName,
          config,
          scope: "openid email profile offline_access",
          callbackURL: `https://${domain}/api/auth/oauth/callback`,
        },
        verify,
      );
      passport.use(strategy);
      registeredStrategies.add(strategyName);
    }
  };

  // OAuth login route - initiates OAuth flow
  app.get("/api/auth/oauth/login", (req, res, next) => {
    ensureStrategy(req.hostname);
    passport.authenticate(`replitauth:${req.hostname}`, {
      prompt: "login consent",
      scope: ["openid", "email", "profile", "offline_access"],
    })(req, res, next);
  });

  // OAuth callback route - handles OAuth provider callback
  app.get("/api/auth/oauth/callback", (req, res, next) => {
    ensureStrategy(req.hostname);
    passport.authenticate(`replitauth:${req.hostname}`, (err: any, user: any, info: any) => {
      if (err) {
        console.error("OAuth callback error:", err);
        return res.redirect("/");
      }
      if (!user) {
        return res.redirect("/");
      }
      
      // Store OAuth tokens in session (separate from user object)
      if (info?.tokens) {
        req.session.oauthTokens = info.tokens;
      }
      
      // Log the user in
      req.login(user, (err) => {
        if (err) {
          console.error("Login error after OAuth:", err);
          return res.redirect("/");
        }
        res.redirect("/");
      });
    })(req, res, next);
  });

  // OAuth logout route
  app.get("/api/auth/oauth/logout", (req, res) => {
    req.logout(() => {
      res.redirect(
        client.buildEndSessionUrl(config, {
          client_id: process.env.REPL_ID!,
          post_logout_redirect_uri: `${req.protocol}://${req.hostname}`,
        }).href
      );
    });
  });
}

// OAuth-specific authentication middleware with token refresh
// NOTE: Only use this for OAuth-specific routes that need token validation
// For general authentication, use the generic isAuthenticated middleware in routes.ts
export const isOAuthAuthenticated: RequestHandler = async (req, res, next) => {
  // Check if user is authenticated
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  // Check if OAuth tokens exist in session
  const oauthTokens = (req.session as any).oauthTokens;
  if (!oauthTokens) {
    // Not an OAuth user - pass through (this middleware is OAuth-specific)
    // Use the generic isAuthenticated middleware for routes that accept both auth types
    return next();
  }

  if (!oauthTokens.expires_at) {
    return next();
  }

  const now = Math.floor(Date.now() / 1000);
  if (now <= oauthTokens.expires_at) {
    return next();
  }

  const refreshToken = oauthTokens.refresh_token;
  if (!refreshToken) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }

  try {
    const config = await getOidcConfig();
    const tokenResponse = await client.refreshTokenGrant(config, refreshToken);
    
    // Update tokens in session
    (req.session as any).oauthTokens = {
      claims: tokenResponse.claims(),
      access_token: tokenResponse.access_token,
      refresh_token: tokenResponse.refresh_token,
      expires_at: tokenResponse.claims()?.exp,
    };
    
    return next();
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
};
