import {
  stories,
  userProgress,
  languagePhrases,
  proverbs,
  badges,
  gameScores,
  users,
  passwordResetTokens,
  type Story,
  type UserProgress,
  type LanguagePhrase,
  type Proverb,
  type Badge,
  type GameScore,
  type User,
  type InsertUser,
  type PasswordResetToken,
  type InsertPasswordResetToken,
} from "@shared/schema";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations (supports both email/password and OAuth)
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByOAuthSub(oauthSub: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  upsertUser(user: Partial<InsertUser> & { id?: string; oauthSub?: string }): Promise<User>;
  updateUser(id: string, updates: Partial<Pick<User, 'firstName' | 'lastName' | 'profileImageUrl'>>): Promise<User>;
  updateUserPassword(userId: string, hashedPassword: string): Promise<void>;
  
  // Password reset token operations
  createPasswordResetToken(userId: string): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenUsed(tokenId: string): Promise<void>;
  deleteExpiredPasswordResetTokens(): Promise<void>;
  
  getStories(): Promise<Story[]>;
  getStoryById(id: string): Promise<Story | undefined>;
  getFeaturedStories(): Promise<Story[]>;
  
  getUserProgress(userId: string): Promise<UserProgress>;
  updateUserProgress(userId: string, progress: Partial<UserProgress>): Promise<UserProgress>;
  completeStory(userId: string, storyId: string): Promise<void>;
  addPoints(userId: string, points: number): Promise<void>;
  
  getPhrasesByLanguage(language: string): Promise<LanguagePhrase[]>;
  getDailyPhrase(): Promise<LanguagePhrase>;
  
  getProverbs(): Promise<Proverb[]>;
  getDailyProverb(): Promise<Proverb>;
  
  getBadges(): Promise<Badge[]>;
  
  saveGameScore(score: GameScore): Promise<void>;
  getGameScores(userId: string): Promise<GameScore[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (email/password authentication)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByOAuthSub(oauthSub: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.oauthSub, oauthSub));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async upsertUser(userData: Partial<InsertUser> & { id?: string; oauthSub?: string }): Promise<User> {
    // For OAuth users: check if user exists by OAuth subject first
    if (userData.oauthSub) {
      const existingByOAuth = await this.getUserByOAuthSub(userData.oauthSub);
      if (existingByOAuth) {
        // User exists with this OAuth sub - update their record
        const [updatedUser] = await db
          .update(users)
          .set({
            email: userData.email ?? existingByOAuth.email,
            firstName: userData.firstName ?? existingByOAuth.firstName,
            lastName: userData.lastName ?? existingByOAuth.lastName,
            profileImageUrl: userData.profileImageUrl ?? existingByOAuth.profileImageUrl,
            updatedAt: new Date(),
          })
          .where(eq(users.id, existingByOAuth.id))
          .returning();
        return updatedUser;
      }
    }

    // Check if user exists by email (for reconciliation across auth methods)
    if (userData.email) {
      const existingByEmail = await this.getUserByEmail(userData.email);
      if (existingByEmail) {
        // User exists with this email - link OAuth to existing account
        const [updatedUser] = await db
          .update(users)
          .set({
            oauthSub: userData.oauthSub ?? existingByEmail.oauthSub,
            firstName: userData.firstName ?? existingByEmail.firstName,
            lastName: userData.lastName ?? existingByEmail.lastName,
            profileImageUrl: userData.profileImageUrl ?? existingByEmail.profileImageUrl,
            updatedAt: new Date(),
          })
          .where(eq(users.id, existingByEmail.id))
          .returning();
        return updatedUser;
      }
    }

    // No existing user - create new
    const newUser: InsertUser = {
      id: userData.id || undefined,
      email: userData.email || null,
      password: userData.password || null,
      oauthSub: userData.oauthSub || null,
      firstName: userData.firstName || null,
      lastName: userData.lastName || null,
      profileImageUrl: userData.profileImageUrl || null,
    };

    const [user] = await db
      .insert(users)
      .values(newUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<Pick<User, 'firstName' | 'lastName' | 'profileImageUrl'>>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserPassword(userId: string, hashedPassword: string): Promise<void> {
    await db
      .update(users)
      .set({
        password: hashedPassword,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  // Password reset token operations
  async createPasswordResetToken(userId: string): Promise<PasswordResetToken> {
    // Generate a secure random token
    const token = randomUUID() + randomUUID();
    // Token expires in 1 hour
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);
    
    const [resetToken] = await db
      .insert(passwordResetTokens)
      .values({
        userId,
        token,
        expiresAt,
      })
      .returning();
    
    return resetToken;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const [resetToken] = await db
      .select()
      .from(passwordResetTokens)
      .where(eq(passwordResetTokens.token, token));
    return resetToken;
  }

  async markPasswordResetTokenUsed(tokenId: string): Promise<void> {
    await db
      .update(passwordResetTokens)
      .set({ usedAt: new Date() })
      .where(eq(passwordResetTokens.id, tokenId));
  }

  async deleteExpiredPasswordResetTokens(): Promise<void> {
    await db
      .delete(passwordResetTokens)
      .where(sql`${passwordResetTokens.expiresAt} < NOW()`);
  }

  async getStories(): Promise<Story[]> {
    return await db.select().from(stories);
  }

  async getStoryById(id: string): Promise<Story | undefined> {
    const [story] = await db.select().from(stories).where(eq(stories.id, id));
    return story || undefined;
  }

  async getFeaturedStories(): Promise<Story[]> {
    const allStories = await db.select().from(stories).limit(3);
    return allStories;
  }

  async getUserProgress(userId: string = "default"): Promise<UserProgress> {
    const [progress] = await db.select().from(userProgress).where(eq(userProgress.userId, userId));
    
    if (!progress) {
      const [newProgress] = await db
        .insert(userProgress)
        .values({
          userId,
          completedStories: [],
          points: 0,
          badges: [],
          currentStreak: 0,
        })
        .returning();
      return newProgress;
    }
    
    return progress;
  }

  async updateUserProgress(userId: string, updates: Partial<UserProgress>): Promise<UserProgress> {
    const [updated] = await db
      .update(userProgress)
      .set(updates)
      .where(eq(userProgress.userId, userId))
      .returning();
    
    if (!updated) {
      throw new Error(`User progress not found for userId: ${userId}`);
    }
    
    return updated;
  }

  async completeStory(userId: string, storyId: string): Promise<void> {
    const progress = await this.getUserProgress(userId);
    
    if (!progress.completedStories.includes(storyId)) {
      const updatedCompletedStories = [...progress.completedStories, storyId];
      const newPoints = progress.points + 20;
      const newStreak = progress.currentStreak + 1;
      
      const earnedBadges = [...progress.badges];
      
      if (updatedCompletedStories.length === 1 && !earnedBadges.includes("1")) {
        earnedBadges.push("1");
      }
      
      if (updatedCompletedStories.length >= 5 && !earnedBadges.includes("2")) {
        earnedBadges.push("2");
      }
      
      const allStories = await this.getStories();
      const completedRegions = new Set(
        allStories
          .filter(s => updatedCompletedStories.includes(s.id))
          .map(s => s.region)
      );
      if (completedRegions.size >= 3 && !earnedBadges.includes("5")) {
        earnedBadges.push("5");
      }
      
      await db
        .update(userProgress)
        .set({
          completedStories: updatedCompletedStories,
          points: newPoints,
          currentStreak: newStreak,
          badges: earnedBadges,
        })
        .where(eq(userProgress.userId, userId));
    }
  }

  async addPoints(userId: string, points: number): Promise<void> {
    const progress = await this.getUserProgress(userId);
    const newPoints = progress.points + points;
    const earnedBadges = [...progress.badges];
    
    if (newPoints >= 100 && !earnedBadges.includes("4")) {
      earnedBadges.push("4");
    }
    
    await db
      .update(userProgress)
      .set({ 
        points: newPoints,
        badges: earnedBadges,
      })
      .where(eq(userProgress.userId, userId));
  }

  async getPhrasesByLanguage(language: string): Promise<LanguagePhrase[]> {
    return await db
      .select()
      .from(languagePhrases)
      .where(eq(languagePhrases.language, language));
  }

  async getDailyPhrase(): Promise<LanguagePhrase> {
    const allPhrases = await db.select().from(languagePhrases);
    const today = new Date().getDate();
    return allPhrases[today % allPhrases.length];
  }

  async getProverbs(): Promise<Proverb[]> {
    return await db.select().from(proverbs);
  }

  async getDailyProverb(): Promise<Proverb> {
    const allProverbs = await db.select().from(proverbs);
    const today = new Date().getDate();
    return allProverbs[today % allProverbs.length];
  }

  async getBadges(): Promise<Badge[]> {
    return await db.select().from(badges);
  }

  async saveGameScore(score: GameScore): Promise<void> {
    await db.insert(gameScores).values(score);
  }

  async getGameScores(userId: string): Promise<GameScore[]> {
    return await db
      .select()
      .from(gameScores)
      .where(eq(gameScores.userId, userId));
  }
}

export const storage = new DatabaseStorage();
