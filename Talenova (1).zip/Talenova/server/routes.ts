import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateAfricanStory } from "./lib/openai";
import { aiStoryRequestSchema, registerUserSchema, loginUserSchema, updateUserSchema, forgotPasswordSchema, resetPasswordSchema, type GameScore, type User } from "@shared/schema";
import { randomUUID } from "crypto";
import { setupAuth, isAuthenticated as isLocalAuthenticated, hashPassword } from "./localAuth";
import { setupOAuth } from "./replitAuth";
import passport from "passport";
import type { RequestHandler } from "express";

// Generic authentication middleware that works for both local and OAuth
export const isAuthenticated: RequestHandler = (req, res, next) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup both authentication systems
  await setupAuth(app);
  await setupOAuth(app);

  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validatedData = registerUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const hashedPassword = await hashPassword(validatedData.password);
      const user = await storage.createUser({
        email: validatedData.email,
        password: hashedPassword,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
      });

      req.login(user, (err) => {
        if (err) {
          console.error("Login after registration error:", err);
          return res.status(500).json({ message: "Failed to log in after registration" });
        }
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
      });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Invalid registration data", details: error.errors });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });

  app.post('/api/auth/login', (req, res, next) => {
    passport.authenticate('local', (err: any, user: User | false, info: any) => {
      if (err) {
        console.error("Login error:", err);
        return res.status(500).json({ message: "Login failed" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      req.login(user, (err) => {
        if (err) {
          console.error("Session creation error:", err);
          return res.status(500).json({ message: "Failed to create session" });
        }
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get('/api/auth/user', isAuthenticated, async (req, res) => {
    try {
      // User object is already sanitized by deserializeUser (password stripped)
      // OAuth tokens are stored separately in req.session, not in user object
      res.json(req.user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.patch('/api/auth/user', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as User;
      const validatedData = updateUserSchema.parse(req.body);
      
      const updates: Partial<Pick<User, 'firstName' | 'lastName' | 'profileImageUrl'>> = {};
      if (validatedData.firstName !== undefined) updates.firstName = validatedData.firstName;
      if (validatedData.lastName !== undefined) updates.lastName = validatedData.lastName;
      if (validatedData.profileImageUrl !== undefined) {
        updates.profileImageUrl = validatedData.profileImageUrl === "" ? null : validatedData.profileImageUrl;
      }

      const updatedUser = await storage.updateUser(user.id, updates);
      
      // Update session user data to reflect changes immediately
      req.user = updatedUser;
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Invalid update data", details: error.errors });
      }
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Forgot password - request password reset
  app.post('/api/auth/forgot-password', async (req, res) => {
    try {
      const { email } = forgotPasswordSchema.parse(req.body);
      
      // Always return success to prevent email enumeration
      const user = await storage.getUserByEmail(email);
      
      if (user && user.password) {
        // Only allow password reset for users with local passwords
        // Clean up expired tokens first
        await storage.deleteExpiredPasswordResetTokens();
        
        // Create a new reset token
        const resetToken = await storage.createPasswordResetToken(user.id);
        
        // In production, this would send an email
        // For development, we'll return the reset link
        const resetLink = `/reset-password?token=${resetToken.token}`;
        
        console.log(`[Password Reset] Reset link for ${email}: ${resetLink}`);
        
        // In development mode, include the token in response for testing
        if (process.env.NODE_ENV === 'development' || !process.env.NODE_ENV) {
          return res.json({ 
            message: "If an account with that email exists, a password reset link has been sent.",
            // Development only - remove in production with email service
            resetLink: resetLink,
            expiresAt: resetToken.expiresAt
          });
        }
      }
      
      // Generic success response to prevent email enumeration
      res.json({ message: "If an account with that email exists, a password reset link has been sent." });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Invalid email address" });
      }
      console.error("Forgot password error:", error);
      res.status(500).json({ message: "Failed to process password reset request" });
    }
  });

  // Verify reset token is valid
  app.get('/api/auth/verify-reset-token', async (req, res) => {
    try {
      const token = req.query.token as string;
      
      if (!token) {
        return res.status(400).json({ valid: false, message: "Reset token is required" });
      }
      
      const resetToken = await storage.getPasswordResetToken(token);
      
      if (!resetToken) {
        return res.status(400).json({ valid: false, message: "Invalid or expired reset link" });
      }
      
      if (resetToken.usedAt) {
        return res.status(400).json({ valid: false, message: "This reset link has already been used" });
      }
      
      if (new Date() > resetToken.expiresAt) {
        return res.status(400).json({ valid: false, message: "This reset link has expired" });
      }
      
      res.json({ valid: true, message: "Reset token is valid" });
    } catch (error) {
      console.error("Verify reset token error:", error);
      res.status(500).json({ valid: false, message: "Failed to verify reset token" });
    }
  });

  // Reset password with token
  app.post('/api/auth/reset-password', async (req, res) => {
    try {
      const { token, password } = resetPasswordSchema.parse(req.body);
      
      const resetToken = await storage.getPasswordResetToken(token);
      
      if (!resetToken) {
        return res.status(400).json({ message: "Invalid or expired reset link" });
      }
      
      if (resetToken.usedAt) {
        return res.status(400).json({ message: "This reset link has already been used" });
      }
      
      if (new Date() > resetToken.expiresAt) {
        return res.status(400).json({ message: "This reset link has expired" });
      }
      
      // Hash the new password
      const hashedPassword = await hashPassword(password);
      
      // Update user's password
      await storage.updateUserPassword(resetToken.userId, hashedPassword);
      
      // Mark the token as used
      await storage.markPasswordResetTokenUsed(resetToken.id);
      
      res.json({ message: "Password has been reset successfully. You can now log in with your new password." });
    } catch (error: any) {
      if (error.name === 'ZodError') {
        const passwordError = error.errors?.find((e: any) => e.path.includes('password') || e.path.includes('confirmPassword'));
        return res.status(400).json({ message: passwordError?.message || "Invalid password data" });
      }
      console.error("Reset password error:", error);
      res.status(500).json({ message: "Failed to reset password" });
    }
  });


  app.get("/api/stories", async (req, res) => {
    try {
      const stories = await storage.getStories();
      res.json(stories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stories" });
    }
  });

  app.get("/api/stories/featured", async (req, res) => {
    try {
      const stories = await storage.getFeaturedStories();
      res.json(stories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch featured stories" });
    }
  });

  app.get("/api/stories/:id", async (req, res) => {
    try {
      const story = await storage.getStoryById(req.params.id);
      if (!story) {
        return res.status(404).json({ error: "Story not found" });
      }
      res.json(story);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch story" });
    }
  });

  app.post("/api/stories/generate", async (req, res) => {
    try {
      const validatedData = aiStoryRequestSchema.parse(req.body);
      const story = await generateAfricanStory(validatedData);
      res.json(story);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      console.error("Story generation error:", error);
      res.status(500).json({ 
        error: error.message || "Failed to generate story",
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      });
    }
  });

  app.get("/api/phrases/:language", async (req, res) => {
    try {
      const phrases = await storage.getPhrasesByLanguage(req.params.language);
      res.json(phrases);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch phrases" });
    }
  });

  app.get("/api/phrases/daily", async (req, res) => {
    try {
      const phrase = await storage.getDailyPhrase();
      res.json(phrase);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch daily phrase" });
    }
  });

  app.get("/api/proverbs", async (req, res) => {
    try {
      const proverbs = await storage.getProverbs();
      res.json(proverbs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch proverbs" });
    }
  });

  app.get("/api/proverbs/daily", async (req, res) => {
    try {
      const proverb = await storage.getDailyProverb();
      res.json(proverb);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch daily proverb" });
    }
  });

  app.get("/api/progress", async (req, res) => {
    try {
      const userId = "default"; // In a real app, this would come from authentication
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress/complete-story", async (req, res) => {
    try {
      const userId = "default";
      const { storyId } = req.body;
      if (!storyId) {
        return res.status(400).json({ error: "Story ID is required" });
      }
      await storage.completeStory(userId, storyId);
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to update progress" });
    }
  });

  app.post("/api/progress/add-points", async (req, res) => {
    try {
      const userId = "default";
      const { points } = req.body;
      if (typeof points !== 'number') {
        return res.status(400).json({ error: "Points must be a number" });
      }
      await storage.addPoints(userId, points);
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to add points" });
    }
  });

  app.get("/api/badges", async (req, res) => {
    try {
      const badges = await storage.getBadges();
      res.json(badges);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch badges" });
    }
  });

  app.post("/api/game-scores", async (req, res) => {
    try {
      const userId = "default";
      const { gameType, score } = req.body;
      
      if (!gameType || typeof score !== 'number') {
        return res.status(400).json({ error: "Game type and score are required" });
      }

      const gameScore = {
        id: randomUUID(),
        userId,
        gameType,
        score,
        completedAt: new Date(),
      };

      await storage.saveGameScore(gameScore);
      await storage.addPoints(userId, score);
      
      const updatedProgress = await storage.getUserProgress(userId);
      res.json({ ...gameScore, progress: updatedProgress });
    } catch (error) {
      console.error("Error saving game score:", error);
      res.status(500).json({ error: "Failed to save game score" });
    }
  });

  app.get("/api/game-scores", async (req, res) => {
    try {
      const userId = "default";
      const scores = await storage.getGameScores(userId);
      res.json(scores);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch game scores" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
