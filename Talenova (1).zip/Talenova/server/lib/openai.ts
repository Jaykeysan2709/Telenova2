// Integration with Replit AI Integrations for OpenAI access
// This uses AI Integrations which provides OpenAI-compatible API access without requiring your own API key
// The newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user

import OpenAI from "openai";
import { type AIStoryRequest, type AIStoryResponse } from "@shared/schema";

if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL) {
  console.error("ERROR: AI_INTEGRATIONS_OPENAI_BASE_URL is not set");
}

if (!process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
  console.error("ERROR: AI_INTEGRATIONS_OPENAI_API_KEY is not set");
}

const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

export async function generateAfricanStory(request: AIStoryRequest): Promise<AIStoryResponse> {
  if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || !process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
    throw new Error("AI Integration is not configured. Missing API credentials.");
  }
  
  let prompt = `You are a master storyteller of African folklore. Create an authentic, age-appropriate African folktale with the following elements:

Main Character: ${request.character}
Moral Lesson: ${request.moral}
Setting/Theme: ${request.theme}
Age Group: ${request.ageGroup}`;

  if (request.supportingCharacter) {
    prompt += `\nSupporting Character: ${request.supportingCharacter}`;
  }
  if (request.storyTone) {
    prompt += `\nStory Tone: ${request.storyTone}`;
  }
  if (request.specialElement) {
    prompt += `\nSpecial Element to Include: ${request.specialElement}`;
  }
  if (request.timeOfDay) {
    prompt += `\nTime of Day: ${request.timeOfDay}`;
  }
  if (request.conflict) {
    prompt += `\nMain Challenge/Conflict: ${request.conflict}`;
  }

  prompt += `

Requirements:
1. The story should be culturally authentic, drawing from real African storytelling traditions
2. Keep the language appropriate for ages ${request.ageGroup}
3. The story should be 300-500 words long
4. Include vivid descriptions of African landscapes, animals, and cultural elements
5. The moral should be woven naturally into the narrative
6. End with a satisfying conclusion that reinforces the lesson`;

  if (request.supportingCharacter || request.storyTone || request.specialElement || request.timeOfDay || request.conflict) {
    prompt += `\n7. Incorporate all the specified optional elements naturally into the story`;
  }

  prompt += `

Return your response as JSON with this exact structure:
{
  "title": "The story title",
  "content": "The full story text with paragraphs separated by \\n\\n",
  "moral": "A clear statement of the moral lesson (1-2 sentences)",
  "culturalContext": "1-2 sentences explaining the cultural significance or traditional elements in the story"
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // Using gpt-4o (GPT-4 Omni) for JSON mode support
      messages: [
        {
          role: "system",
          content: "You are an expert in African folklore and storytelling traditions. You create authentic, culturally-rich stories that educate and inspire children while preserving African heritage.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2000,
    });

    const content = response.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error("Failed to generate story - no content in response");
    }

    const storyData = JSON.parse(content);
    
    return {
      title: storyData.title || "",
      content: storyData.content || "",
      moral: storyData.moral || "",
      culturalContext: storyData.culturalContext || storyData.cultural_context || "",
    };
  } catch (error: any) {
    console.error("OpenAI API Error:", {
      message: error.message,
      status: error.status,
      type: error.type,
      code: error.code,
    });
    throw new Error(`AI Story Generation Failed: ${error.message || "Unknown error"}`);
  }
}
