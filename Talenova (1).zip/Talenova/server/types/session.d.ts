import 'express-session';

declare module 'express-session' {
  interface SessionData {
    oauthTokens?: {
      claims: any;
      access_token: string;
      refresh_token?: string;
      expires_at?: number;
    };
  }
}
